<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('../meta.php');
    ?>
</head>
<body class="animsition">
    <div class="page-wrapper">
        <?php
            include_once('../menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr class="text-center">
                                                <th>Câu hỏi</th>
                                                <th>A</th>
                                                <th>B</th>
                                                <th>C</th>
                                                <th>D</th>
                                                <th>ĐA</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        if(!isset($_SESSION['user']) || $user!='lieutuanvu'){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Khu vực chỉ dành cho admin
        									</div>';
        									echo'
                                            <script>
                                                window.location="../dang-nhap";
                                            </script>';
                                        } else{
                                                $layCauHoi = $ketnoi->query("SELECT * FROM `cau_hoi` ORDER BY `idcauhoi` DESC");
                                                if($layCauHoi && $layCauHoi->num_rows>0){
                                                    while($row = $layCauHoi->fetch_assoc()){
                                                        $dA= '';
                                                        if($row['da']==1) $dA= 'A';
                                                        else if($row['da']==2) $dA= 'B';
                                                        else if($row['da']==3) $dA= 'C';
                                                        else $dA= 'D';
                                                        echo'
                                                        <tr class="tr-shadow" id="'.$row['idcauhoi'].'">
                                                            <td>'.$row['cauhoi'].'</td>
                                                            <td>'.$row['a'].'</td>
                                                            <td>'.$row['b'].'</td>
                                                            <td>'.$row['c'].'</td>
                                                            <td>'.$row['d'].'</td>
                                                            <td>'.$dA.'</td>
                                                            <td>
                                                                <div class="table-data-feature">
                                                                    <button class="item" data-placement="top" data-toggle="modal" title="Sửa câu hỏi" onClick="sua('.$row['idcauhoi'].')" data-target="#suaCauHoi" data-original-title="Edit">
                                                                        <i class="zmdi zmdi-edit"></i>
                                                                    </button>
                                                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Xoá câu hỏi" onClick="xoaCauHoi('.$row['idcauhoi'].','."'(".$row['cauhoi'].")'".')" data-original-title="Delete">
                                                                        <i class="zmdi zmdi-delete"></i>
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr class="spacer"></tr>';
                                                    }
                                                }
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php
                            include_once('../footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal medium -->
			<div class="modal fade" id="suaCauHoi" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Sửa câu hỏi</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body" id="chiTietCauHoi">
						</div>
					</div>
				</div>
			</div>
			<!-- end modal medium -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.0.js"></script>
    <script>
    <?php
    if($user=="lieutuanvu"){
    echo'
    function thongBaoSuaCauHoiThanhCong(){
        swal({
          title: "Đã sửa câu hỏi!",
          icon: "success",
          button: "Quá tuyệt!",
        });
    }
    function thongBaoXoaCauHoiThanhCong(){
        swal({
          title: "Đã xoá câu hỏi!",
          icon: "success",
          button: "Quá tuyệt!",
        });
    }';
    }
    ?>
    <?php
        $thongBao = isset($_GET['tb'])?$_GET['tb']:'';
        if($user=='lieutuanvu' && $thongBao=='S'){
            echo 'thongBaoSuaCauHoiThanhCong();';
        }
        if($user=='lieutuanvu' && $thongBao=='X'){
            echo 'thongBaoXoaCauHoiThanhCong();';
        }
    ?>
    <?php
    if($user=="lieutuanvu"){
    echo'
    function sua(idCauHoi){
        document.getElementById("chiTietCauHoi").innerHTML="Chờ tí...";
        $("#chiTietCauHoi").load("suaCauHoi.php?idcauhoi="+idCauHoi);
    }
    function xoa(idCauHoi){
        window.location = "xoaCauHoi.php?idcauhoi="+idCauHoi;
    }
    function xoaCauHoi(idCauHoi,cauHoi){
        swal("Thiệt sự muốn xoá câu hỏi "+cauHoi+" sao??", {
            icon: "warning",
            buttons: {
                  delete : "Xoá đi!!!",
                  cancle:"Hông xoá nữa!"
              },
        })
        .then((value)=>{
            switch (value) {
 
                case "delete":
                  xoa(idCauHoi);
                  break;
             
                default:
                    swal("Okk hông xoá!");
            }
        });
    }';
    }
    ?>
    </script>

    <?php
        include_once('../script.php')
    ?>
</body>

</html>

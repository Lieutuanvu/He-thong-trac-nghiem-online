<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
                                    <?php
                                        if(!isset($_GET['idcauhoi']) || !isset($_SESSION['user']) || $user!='lieutuanvu'){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Khu vực chỉ dành cho admin
        									</div>';
                                            header('Location: ../quan-ly-cau-hoi');
                                        } else {
                                            /////Phan nay xu ly xoa cau hoi
                                            $idCauHoi = isset($_GET['idcauhoi']) ? $_GET['idcauhoi'] :'';
                                            if($idCauHoi!=''){
                                                $xoaCacBoDecoCauHoi = $ketnoi->query("DELETE FROM `cauhoi_thuoc_bode` WHERE `idcauhoi`='$idCauHoi'");
                                                $xoaCacBoDecoCauHoi;
                                                $xoaCauHoi = $ketnoi->query("DELETE FROM `cau_hoi` WHERE `idcauhoi`='$idCauHoi'");
                                                $xoaCauHoi;
                                                header('Location: ../quan-ly-cau-hoi?tb=X#'.($idCauHoi+1));
                                            }
                                        }
                                    ?>
<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
                                    <?php
                                        if(!isset($_GET['idcauhoi']) || !isset($_SESSION['user']) || $user!='lieutuanvu'){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Khu vực chỉ dành cho admin
        									</div>';
        									header('Location: ../quan-ly-cau-hoi');
                                        } else if(isset($_SESSION['user']) && $user=='lieutuanvu'){
                                            /////Phan nay xu ly sua cau hoi
                                            $idCauHoi = isset($_GET['idcauhoi']) ? $_GET['idcauhoi'] :'';
                                            $cauHoi = isset($_POST['Cau']) ? $_POST['Cau']:'';
                                            $A = isset($_POST['A']) ? $_POST['A']:'';
                                            $B = isset($_POST['B']) ? $_POST['B']:'';
                                            $C = isset($_POST['C']) ? $_POST['C']:'';
                                            $D = isset($_POST['D']) ? $_POST['D']:'';
                                            $DA = isset($_POST['DA']) ? $_POST['DA']:'';
                                            if($idCauHoi!='' && $cauHoi!='' && $A!='' && $B!='' && $C!='' && $D!='' && $DA!=''){
                                                $suaCauHoi = $ketnoi->query("UPDATE `cau_hoi` SET `cauhoi`='$cauHoi',`a`='$A',`b`='$B',`c`='$C',`d`='$D',`da`='$DA' WHERE `idcauhoi`='$idCauHoi'");
                                                $suaCauHoi;
                                                $xoaCacBoDecoCauHoi = $ketnoi->query("DELETE FROM `cauhoi_thuoc_bode` WHERE `idcauhoi`='$idCauHoi'");
                                                $xoaCacBoDecoCauHoi;
                                                $boDe = isset($_POST['bode']) ? $_POST['bode']: array();
                                                foreach($boDe as $de){
                                                    $themCauHoiVaoDe = $ketnoi->query("INSERT INTO `cauhoi_thuoc_bode`(`idbode`, `idcauhoi`) VALUES ('$de','$idCauHoi')");
                                                    $themCauHoiVaoDe;
                                                }
                                                header('Location: ../quan-ly-cau-hoi?tb=S#'.$idCauHoi);
                                            } else if($idCauHoi!=''){
                                                $layChiTietCauHoi = $ketnoi->query("SELECT * FROM `cau_hoi` WHERE `idcauhoi`='$idCauHoi'");
                                                if($layChiTietCauHoi && $layChiTietCauHoi->num_rows>0){
                                                    while($in = $layChiTietCauHoi->fetch_assoc()){
                                                        $cA = '';$cB = '';$cC = '';$cD = '';
                                                        if($in['da']==1){
                                                            $cA = 'checked';
                                                        } else if($in['da']==2){
                                                            $cB = 'checked';
                                                        } else if($in['da']==3){
                                                            $cC = 'checked';
                                                        } else $cD = 'checked';
                                                        echo'
                                                        <form action="suaCauHoi.php?idcauhoi='.$idCauHoi.'" method="post" class="">
                                                            <div class="form-group">
                                                                <div class="col col-md-12">
                                                                    <label for="multiple-select" class=" form-control-label">Chọn bộ đề chứa câu hỏi (ctrl chọn nhiều)</label>
                                                                </div>
                                                                <div class="col col-md-12">
                                                                    <select name="bode[]" id="multiple-select" multiple="" class="form-control" autofocus>';
                                                                $layCacBoDe = $ketnoi->query("SELECT * FROM `bo_de`");
                                                                if($layCacBoDe && $layCacBoDe->num_rows>0){
                                                                    while($row=$layCacBoDe->fetch_assoc()){
                                                                        $idBoDe = $row['idbode'];
                                                                        $selected = '';
                                                                        $ktXemCauHoiThuocDeNay=$ketnoi->query("SELECT * FROM `cauhoi_thuoc_bode` WHERE `idcauhoi`='$idCauHoi' AND `idbode`='$idBoDe'");
                                                                        if($ktXemCauHoiThuocDeNay && $ktXemCauHoiThuocDeNay->num_rows>0) $selected = 'selected';
                                                                        echo'
                                                                        <option value="'.$row['idbode'].'" '.$selected.'>'.$row['tenbode'].'</option>
                                                                        ';
                                                                    }
                                                                }
                                                            echo'
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-group">
                                                                    <div class="input-group-addon">
                                                                        <i class="fa fa-question-circle"></i>
                                                                    </div>
                                                                    <input required type="text" name="Cau" value="'.$in['cauhoi'].'" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-group">
                                                                    <div class="input-group-addon">
                                                                        <label class="switch switch-text switch-primary switch-pill">
                                                                            <input required type="radio" name="DA" class="switch-input" value="1" '.$cA.'>
                                                                            <span data-on="T" data-off="F" class="switch-label"></span>
                                                                            <span class="switch-handle"></span>
                                                                        </label>
                                                                    </div>
                                                                    <input required type="text" name="A" value="'.$in['a'].'" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-group">
                                                                    <div class="input-group-addon">
                                                                        <label class="switch switch-text switch-primary switch-pill">
                                                                            <input required type="radio" name="DA" class="switch-input" value="2" '.$cB.'>
                                                                            <span data-on="T" data-off="F" class="switch-label"></span>
                                                                            <span class="switch-handle"></span>
                                                                        </label>
                                                                    </div>
                                                                    <input required type="text" name="B" value="'.$in['b'].'" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-group">
                                                                    <div class="input-group-addon">
                                                                        <label class="switch switch-text switch-primary switch-pill">
                                                                            <input required type="radio" name="DA" class="switch-input" value="3" '.$cC.'>
                                                                            <span data-on="T" data-off="F" class="switch-label"></span>
                                                                            <span class="switch-handle"></span>
                                                                        </label>
                                                                    </div>
                                                                    <input required type="text" name="C" value="'.$in['c'].'" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-group">
                                                                    <div class="input-group-addon">
                                                                        <label class="switch switch-text switch-primary switch-pill">
                                                                            <input required type="radio" name="DA" class="switch-input" value="4" '.$cD.'>
                                                                            <span data-on="T" data-off="F" class="switch-label"></span>
                                                                            <span class="switch-handle"></span>
                                                                        </label>
                                                                    </div>
                                                                    <input required type="text" name="D" value="'.$in['d'].'" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="card-footer">
                                                                <div class="form-actions form-group">
                                                                    <button type="submit" class="btn btn-success btn-sm">Sửa</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                        ';
                                                    }
                                                } else{
                                                    echo 'Không tìm thấy câu hỏi ùi!!!';
                                                }
                                            } else {
                                                header('Location: ../quan-ly-cau-hoi');
                                            }
                                            
                                        }
                                    ?>

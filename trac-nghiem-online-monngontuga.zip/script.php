    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.0.js"></script>
    <script src="../vendor/jquery-3.2.1.min.js"></script>
    <script src="../vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="../vendor/animsition/animsition.min.js"></script>
    <script src="../vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="../vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="../vendor/circle-progress/circle-progress.min.js"></script>
    <script src="../vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="../vendor/select2/select2.min.js">
    </script>
    <script src="../js/main.js"></script>
    <?php
    if($user!='' && $_SESSION['xacThuc']==0 && strpos($_SERVER['REQUEST_URI'],"thong-tin-thanh-vien")===false)
        echo'
            <script>
                swal({
                  title: "Tài khoản chưa xác thực",
                  text: "Chỉ có thể làm bài bình thường, không thể tham gia các cuộc thi có giải thưởng trên web (nếu có). Nhấn OK để tiến hành xác thực",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                })
                .then((willDelete) => {
                  if (willDelete) {
                    window.location="../thong-tin-thanh-vien";
                  } else {
                    swal("Bạn vẫn là tài khoản chưa xác thực");
                  }
                });
            </script>';
    ?>
    <?php
        $ketnoi->close();
    ?>
<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    if(isset($_POST['doi_hoten']) || isset($_FILES['doi_avt']) && $user!=''){
        if(isset($_POST['doi_hoten'])){
            $doi_hoten = $_POST['doi_hoten'];
            if(isset($_POST['is_doimk']) && $_POST['is_doimk']=="1" && isset($_POST['doi_password'])){
                $newPass = md5($_POST['doi_password']);
                $capNhat = $ketnoi->query("UPDATE `tai_khoan` SET `matkhau`='$newPass',`hoten`='$doi_hoten' WHERE `taikhoan`='$user'");
                $capNhat;
            } else {
                $capNhat = $ketnoi->query("UPDATE `tai_khoan` SET `hoten`='$doi_hoten' WHERE `taikhoan`='$user'");
                $capNhat;
            }
        }
        if(isset($_FILES['doi_avt'])){
            $anhCu='';
            $layTenFileAnhCu = $ketnoi->query("SELECT `avt` FROM `tai_khoan` WHERE `taikhoan`='$user'");
            if($layTenFileAnhCu && $layTenFileAnhCu->num_rows>0)
                while($row = $layTenFileAnhCu->fetch_assoc())
                    $anhCu = $row['avt'];
            $duongDanTamThoi = $_FILES['doi_avt']['tmp_name'];
            $tenFile = $_FILES['doi_avt']['name'];
            $kichThuocFile = $_FILES['doi_avt']['size'];
            $fileType = $_FILES['doi_avt']['type'];
            $fileExtension = pathinfo($tenFile, PATHINFO_EXTENSION);
            $newFileName = md5($user.time("H:i:s")).'.'.$fileExtension;
            $allowedfileExtensions = array('jpg', 'gif', 'png','JPG','GIF','PNG');
            $thuMucChua = '../images/avt/';
            include("resize_avt.php");
            $dest_path = $thuMucChua . $newFileName;
            //Giảm kích thước ảnh
            resize_crop_image(100,100,$duongDanTamThoi,$duongDanTamThoi);
            if (in_array($fileExtension, $allowedfileExtensions)){
                if($anhCu!='default.png' &&$fileExtension!='')
                    unlink($thuMucChua.$anhCu);//Xoa anh cu de tiet kiem bo nho
                if(move_uploaded_file($duongDanTamThoi, $dest_path)){
                    $avtMoi = $newFileName;
                    $capNhat = $ketnoi->query("UPDATE `tai_khoan` SET `avt`='$avtMoi' WHERE `taikhoan`='$user'");
                    $capNhat;
                }
            }
        }
        echo '
                <script>
                    window.location=("../thong-tin-thanh-vien");
                </script>';
    }
    $layThongTinUser = $ketnoi->query("SELECT * FROM `tai_khoan` WHERE `taikhoan`='$user'");
    $avt = '';
    $email = '';
    $hoTen = '';
    $blocked='';
    $xacThuc=0;
    $tinhTrang = '<span class=" badge badge-warning">Chưa xác thực</span>';
    if($layThongTinUser && $layThongTinUser->num_rows>0 && $user!='')
        while($row =$layThongTinUser->fetch_assoc()){
            $avt = $row['avt'];
            $hoTen = $row['hoten'];
            $blocked = $row['blocked'];
            $email = $row['email'];
            $xacThuc = $row['da_xac_thuc'];
        }
        $taikhoan=$user;
        if ($email=='' || $email=='null')
            $email = '<span class=" badge badge-warning">Chưa xác thực</span>';
        else {
            $email = $email.' <i class="zmdi zmdi-check-circle"></i>';
            $taikhoan = $user.' <i class="zmdi zmdi-check-circle"></i>';
            $tinhTrang = '<span class=" badge badge-success">Đã xác thực</span>';
        }
    $ktXemDaGuiMailChua = $ketnoi->query("SELECT * FROM `xac_thuc_mail` WHERE `taikhoan`='$user'");
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('../meta.php');
    ?>
</head>
<body class="animsition">
    <div class="page-wrapper">
        <?php
            include_once('../menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <?php
                                if($user!=""){
                                    echo'
                                <div class="col-md-12">
                                    <div class="card border border-secondary">
                                        <div class="card-body">
                                            <div class="mx-auto d-block">
                                                <img class="img rounded mx-auto d-block" width="100px" height="100px" src="../images/avt/'.$avt.'" alt="Ảnh đại diện">';
                                                if(!$xacThuc){
                                                    if($ktXemDaGuiMailChua && $ktXemDaGuiMailChua->num_rows==0){
                                                        echo'
                                                        <div id="thongbao"></div>
                                                        <hr>
                                                        <div class="row" id="verifyMail">
                                                            <div class="col-sm-6" id="nutNhanMail">
                                                                <button id="xacThucEmail" type="button" class="btn btn-warning btn-lg btn-block">Xác thực Email</button>
                                                            </div>
                                                            <div class="col-sm-6" id="nutNhapMaXacThuc" hidden>
                                                                <button id="nhapMaXacThuc" type="button" class="btn btn-primary btn-lg btn-block">Nhập mã xác thực</button>
                                                            </div>
                                                        </div>';
                                                    }
                                                    else {
                                                        echo'
                                                        <div id="thongbao"></div>
                                                        <hr>
                                                        <div class="row" id="verifyMail">
                                                            <div class="col-sm-6" id="nutNhanMail">
                                                                <button id="xacThucEmail" type="button" class="btn btn-warning btn-lg btn-block">Xác thực Email</button>
                                                            </div>
                                                            <div class="col-sm-6" id="nutNhapMaXacThuc">
                                                                <button id="nhapMaXacThuc" type="button" class="btn btn-primary btn-lg btn-block">Nhập mã xác thực</button>
                                                            </div>
                                                        </div>';
                                                    }
                                                }
                                            echo'    
                                                <hr>
                                                    <div class="col-md-12 offset-md-3">
                                                        <div class="row form-group">
                                                            <div class="col-6 col-sm-3">
                                                                <label class=" form-control-label">Tài khoản: </label>
                                                            </div>
                                                            <div class="col-6 col-sm-6" text-left>
                                                                <p class="form-control-static">'.$taikhoan.'</p>
                                                            </div>
                                                        </div>
                                                        <div class="row form-group">
                                                            <div class="col-6 col-sm-3">
                                                                <label class=" form-control-label">Email: </label>
                                                            </div>
                                                            <div class="col-6 col-sm-6" text-left>
                                                                <p class="form-control-static">'.$email.'</p>
                                                            </div>
                                                        </div>
                                                        <div class="row form-group">
                                                            <div class="col-6 col-sm-3">
                                                                <label class=" form-control-label">Tên hiển thị: </label>
                                                            </div>
                                                            <div class="col-6 col-sm-6" text-left>
                                                                <p class="form-control-static">'.$hoTen.'</p>
                                                            </div>
                                                        </div>
                                                        <div class="row form-group">
                                                            <div class="col-6 col-sm-3">
                                                                <label class=" form-control-label">Tình trạng tài khoản: </label>
                                                            </div>
                                                            <div class="col-6 col-sm-6" text-left">
                                                                <p class="form-control-static">'.$tinhTrang.'</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                            </div>
                                            <hr>
                                            <div class="card-text">
                                                <form id="doi_thong_tin" action="" method="post" enctype="multipart/form-data">
                                                    <div class="form-group">
                                                        <label for="edit_hoten" class="control-label mb-1">Họ tên</label>
                                                        <input id="edit_hoten" maxlength="35" value="'.$hoTen.'" placeholder="'.$hoTen.'" name="doi_hoten" type="text" class="form-control" aria-required="true">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="avt-input" class="form-control-label">Đổi ảnh đại diện</label>
                                                        <input type="file" id="avt-input" name="doi_avt" accept="image/*" class="form-control-file">
                                                    </div>
                                                    <div class="form-group">
                                                        Đổi mật khẩu? 
                                                        <label class="switch switch-text switch-danger switch-pill">
                                                          <input id="doiMK" type="checkbox" name="is_doimk" class="switch-input" value="0">
                                                          <span data-on="Đổi" data-off="No" size="lg" class="switch-label"></span>
                                                          <span class="switch-handle"></span>
                                                        </label>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="input-group">
                                                            <div class="input-group-addon">New pass:</div>
                                                            <input id="pass_change" type="password" name="doi_password" placeholder="Mật khẩu mới" class="form-control">
                                                            <div class="input-group-addon">
                                                                <i class="fa fa-asterisk"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                                <div>
                                                    <input id="chon_doi_thong_tin" type="button" value="Đổi thông tin" class="btn btn-lg btn-info btn-block">
                                                </div>
                                            </div>
                                        </div>';
                                
                                echo'
                                        <div class="table-responsive m-b-40">
                                            <table class="table table-borderless table-data3">
                                                <thead>
                                                    <tr>
                                                        <th class="text-center">IP gần đây</th>
                                                        <th class="text-center">Thời điểm</th>
                                                    </tr>
                                                </thead>
                                                <tbody>';
                                $layLogDN = $ketnoi->query("SELECT * FROM `log_dang_nhap` WHERE `taikhoan`='$user' ORDER BY `thoidiem` DESC LIMIT 5 ");
                                if($layLogDN && $layLogDN->num_rows>0)
                                    while($row=$layLogDN->fetch_assoc())
                                        echo'
                                                    <tr>
                                                        <td class="text-center">'.$row['ip'].'</td>
                                                        <td class="text-center">'.(new DateTime($row['thoidiem']))->format('H:i:s').' ngày '.(new DateTime($row['thoidiem']))->format('d-m-Y').'</td>
                                                    </tr>';
                                echo'
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                    ';
                                    
                                }
                                else echo'
                                    <script>
                                        window.location=("../dang-nhap");
                                    </script>';
                                
                            ?>

                        </div>
                        <?php
                            include_once('../footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php
        include_once('../script.php')
    ?>
</body>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
function guiMailXacNhan(mail){
    $.post( "sendMail.php", { email: mail})
    .done(function(data) {
        $("#thongbao").html(data);
    });
}
function xacNhan(maso){
    $.post( "xacThucMail.php", { maxacthuc: maso})
    .done(function(data) {
        $("#thongbao").html(data);
    });
}
$("#nutNhapMaXacThuc").click(function(){
    swal("Nhập mã xác thực (4 số) bạn đã nhận:", {
      content: "input",
    })
    .then((value) => {
      xacNhan(value);
    });
});


$("#xacThucEmail").click(function(){
    swal("Nhập Email của bạn để nhận mã xác thực:", {
      content: "input",
    })
    .then((email) => {
        switch (email) {
        case "":
          swal("Sao để khoảng trống vậy bạn!!!");
          break;
     
        default:
                swal(`Email của bạn là: ${email} đúng chưa?`, {
                  buttons: {
                    cancel: "Chưa!",
                    catch: {
                      text: "Đúng ời",
                      value: "dung",
                    },
                  },
                })
                .then((value) => {
                  switch (value) {
                    case "dung":
                      guiMailXacNhan(email);
                      break;
                    default:
                      swal("Nhập lại mail đê!!");
                  }
                });
      }
    });
});

$( document ).ready(function() {
    $("#doi_thong_tin").hide();
    $("#pass_change").attr("disabled","");
    $("#chon_doi_thong_tin").click(function(){
        var i = $(this).val();
        if(i=="Đổi thông tin"){
            $("#doi_thong_tin").show(1000);
            $(this).val("Xác nhận đổi");
        } else{
            $("#doi_thong_tin").submit();
        }
    });
    $("#doiMK").change(function(){
        var i = $(this).val();
        if(i == 0){
            $("#pass_change").removeAttr("disabled","");
            $(this).val(1);
        }
        else {
            $("#pass_change").attr("disabled","");
            $(this).val(0);
        }
    })
});
</script>
</html>

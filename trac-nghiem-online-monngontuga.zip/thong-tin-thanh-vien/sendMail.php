<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
include_once("../csdl.php");
$user = isset($_SESSION['user']) ? $_SESSION['user']:'';
$emailNhan = isset($_POST['email'])?strtolower($_POST['email']):'';
if(stripos($emailNhan,"@student.ctu.edu.vn")!=''){
    if($user!='' && $emailNhan!=''){
        $ktXemCoTrungMailKhong = $ketnoi->query("SELECT * FROM `tai_khoan` WHERE lower(`email`)='$emailNhan' AND `da_xac_thuc`=1");
        if($ktXemCoTrungMailKhong && $ktXemCoTrungMailKhong->num_rows>0)
            echo '<script>swal("Email đã xác thực!", "'.$emailNhan.' đã được xác thực cho tài khoản khác!", "error");</script>';
        else {
            $ktXemCoTrungMailKhong = $ketnoi->query("SELECT * FROM `xac_thuc_mail` WHERE `taikhoan`<>'$user' AND lower(`email`)='$emailNhan'");
            if($ktXemCoTrungMailKhong && $ktXemCoTrungMailKhong->num_rows>0)
                echo '<script>swal("Email đang xác thực!", "'.$emailNhan.' đang được xác thực cho tài khoản khác!", "error");</script>';
            else {
                $xoaTokenCu = $ketnoi->query("DELETE FROM `xac_thuc_mail` WHERE `taikhoan`='$user'");
                $xoaTokenCu;
                $newToken = rand(1000,9999);
                $themToken = $ketnoi->query("INSERT INTO `xac_thuc_mail`(`taikhoan`, `email`, `token`) VALUES ('$user','$emailNhan','$newToken')");
                $themToken;
                guiMail($user,$emailNhan,$newToken);
            }
        }
    }else 
        if($user=='')
           echo '<script>swal("Chưa đăng nhập!", "Đăng nhập đi rồi hẳn tính em ei!", "error");</script>';
    else if($emailNhan=='')
                   echo '<script>swal("Nhập lại!", "Nhập lại email đê!", "error");</script>';
} else {
    echo '<script>swal("Email không hợp lệ!", "Chỉ xác nhận email của trường CTU thoii!", "error");</script>';
} 

function guiMail($user,$diachiMail,$maXacThuc){
    //Import PHPMailer classes into the global namespace
    //These must be at the top of your script, not inside a function
    //Load Composer's autoloader
    //require 'vendor/autoload.php';
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
    //Instantiation and passing `true` enables exceptions
    $mail = new PHPMailer(true);

    
    try {
        //Server settings
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'lieutuanvu2001@gmail.com';                     //SMTP username
        $mail->Password   = 'xqqrepwlptlajxgs';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
        $mail->SMTPDebug  = 0; 

        //Recipients
        $mail->setFrom('lieutuanvu2001@gmail.com', 'Administrator at Monngontu.ga');
        $mail->addAddress($diachiMail, 'Monngontu.ga Member');     //Add a recipient
        $mail->addAddress($diachiMail);               //Name is optional
        $mail->addReplyTo('lieutuanvu2001@gmail.com', 'LieuTuanVu');
        $mail->addCC('lieutuanvu2001@gmail.com');
        $mail->addBCC('lieutuanvu2001@gmail.com');
    
        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Email Verify at Monngontu.ga';
        $mail->Body    = 'Mã xác thực của bạn là: <p><b>'.$maXacThuc.'</b></p> để xác thực tài '.$user.' khoản trên monngontu.ga bạn nhé!';
        $mail->AltBody = 'LieuTuanVu - quanancuongloan.com';
    
        if($mail->send())
           echo '<script>
                        $("#xacThucEmail").attr("disabled","");
                        $("#nutNhapMaXacThuc").removeAttr("hidden","");
                        $("#nutNhapMaXacThuc").show(1000);
                        swal("Đã gửi!", "Kiểm tra mail '.$diachiMail.' bạn nhé!", "success");
                </script>';
    } catch (Exception $e) {
        echo '<script>swal("Đang xảy ra lỗi!", "Đang có lỗi trên hệ thống, admin đang fix bạn nhé!", "error");</script>';
    }
}

?>
<?php
include_once("../csdl.php");
$user = isset($_SESSION['user']) ? $_SESSION['user']:'';
$token = isset($_POST['maxacthuc'])?$_POST['maxacthuc']:'';
$email = '';
$mxt = '';
$taikhoan = '';
if($user!='' && $token!=''){
    $layThongTinXacThuc = $ketnoi->query("SELECT * FROM `xac_thuc_mail` WHERE `taikhoan`='$user' AND `token`='$token'");
    if($layThongTinXacThuc && $layThongTinXacThuc->num_rows>0){
        while($row = $layThongTinXacThuc->fetch_assoc()){
            $email = $row['email'];
            $mxt = $row['token'];
            $taikhoan = $row['taikhoan'];
        }
        if($taikhoan==$user && $mxt==$token){
            $xacThuc = $ketnoi->query("UPDATE `tai_khoan` SET `email`='$email',`da_xac_thuc`=1 WHERE `taikhoan`='$user';");
            $xacThuc;
            $xoaToken = $ketnoi->query("DELETE FROM `xac_thuc_mail` WHERE `taikhoan`='$user'");
            $xoaToken;
            $_SESSION['xacThuc']=1;
            echo '<script>
                    function reload(){
                        window.location = "../thong-tin-thanh-vien";
                    }
                    swal("Đã xác thực!", "Tài khoản của bạn đã được xác thực thành công!", "success")
                    .then(()=>{
                        reload();
                    });
                    $("#nutNhapMaXacThuc").hide();
                    $("#xacThucEmail").hide();
                  </script>';
        } else 
            echo '<script>swal("Sai mã xác thực!", "Nhập lại mã xác thực đê!", "error");</script>';
    } else 
        echo '<script>swal("Sai mã xác thực!", "Nhập lại mã xác thực đê!", "error");</script>';
}else if($user=='')
        echo '<script>swal("Chưa đăng nhập!", "Đăng nhập đi rồi hẳn tính em ei!", "error");</script>';
 else if($token=='')
        echo '<script>swal("Nhập lại!", "Nhập lại mã xác thực đê!", "error");</script>';
?>
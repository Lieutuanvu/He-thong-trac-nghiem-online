<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    session_destroy();
    header('Location: ../');
?>
<?php 
$db_host="localhost";
$db_name="quananc1_ltv";
$db_user="quananc1_lieutuanvu";
$db_pass="Lieutuanvublog079";
session_start(); 
header('Content-Type: text/html; charset=utf-8');
$ketnoi=new mysqli($db_host,$db_user,$db_pass,$db_name);
$ketnoi->set_charset("utf8");
?>
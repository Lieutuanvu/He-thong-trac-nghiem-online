<?php
require_once("csdl.php");
date_default_timezone_set('Asia/Ho_Chi_Minh');
$now = date("Y-m-d H:i:s");
$layCacDsDangLam = $ketnoi->query("SELECT * FROM `dang_lam_bo_de` WHERE `ketthuc` <='$now'");
$layCacDsDangLam;
if($layCacDsDangLam && $layCacDsDangLam->num_rows>0){
    while($row = $layCacDsDangLam->fetch_assoc()){
        $user = $row['taikhoan'];
        $idDe = $row['idbode'];
        $laySoCauDaTL = $ketnoi->query("SELECT * FROM `tra_loi` WHERE `taikhoan`='$user' AND `idbode`='$idDe'");
        $soCauDaTL = $laySoCauDaTL->num_rows;
        $laySoCauDung = $ketnoi->query("SELECT DISTINCT * FROM `cau_hoi` `ch`, (SELECT `idcauhoi`,`da` FROM `tra_loi` WHERE `taikhoan`='$user' AND `idbode`='$idDe') `traloi` WHERE `ch`.idcauhoi=`traloi`.idcauhoi AND `ch`.da=`traloi`.da");
        $laySoCauDung;
        if($laySoCauDung->num_rows>0)
            $soCauDung = $laySoCauDung->num_rows;
        else $soCauDung=0;
        $xoaDiemcu = $ketnoi->query("DELETE FROM `diem_so` WHERE `taikhoan` ='$user' AND `idbode`='$idDe'");
        $xoaDiemCu;
        $layThoiGianBoDe = $ketnoi->query("SELECT * FROM `bo_de` WHERE `idbode`='$idDe'");
        $thoiGian = 0;
        if($layThoiGianBoDe && $layThoiGianBoDe->num_rows>0)
            while($lay = $layThoiGianBoDe->fetch_assoc())
                $thoiGian = $lay['thoigian'];
        $thoiGian = date("H:i:s",$thoiGian*1000000);
        $chamDiem = $ketnoi->query("INSERT INTO `diem_so`(`taikhoan`, `idbode`, `socau`, `tongdiem`,`thoigian`) VALUES ('$user','$idDe','$soCauDaTL','$soCauDung','$thoiGian')");
        $chamDiem;
        $xoaBaiDangLam = $ketnoi->query("DELETE FROM `dang_lam_bo_de` WHERE `taikhoan`='$user' AND `idbode`='$idDe'");
        $xoaBaiDangLam;
        $xoaCauTLcu = $ketnoi->query("DELETE FROM `tra_loi` WHERE `taikhoan` ='$user' AND `idbode`='$idDe'");
        $xoaCauTLcu;
        echo $row['taikhoan'].' '.$row['idbode'];
    }
} 
echo $layCacDsDangLam->num_rows;
?>
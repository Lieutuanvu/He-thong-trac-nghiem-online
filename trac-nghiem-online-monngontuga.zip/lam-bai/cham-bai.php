<?php
include_once('../csdl.php');
date_default_timezone_set('Asia/Ho_Chi_Minh');
$now = date("Y-m-d H:i:s");
if(isset($_SESSION['user'])){
    $user = $_SESSION['user'];
    $idDe = isset($_POST['debai']) ? $_POST['debai']:'';
    $Cau = isset($_POST['Cau']) ? $_POST['Cau']:'';
    $action = isset($_GET['action']) ? $_GET['action']:'';
    if(!isset($_POST['debai']) || !isset($_POST['Cau'])) 
        header('Location: ../');
    else if($action=='nop'){
        $ktXemCoDangLamBai = $ketnoi->query("SELECT * FROM `dang_lam_bo_de` WHERE `taikhoan`='$user' AND `idbode`='$idDe'");
        if($ktXemCoDangLamBai && $ktXemCoDangLamBai->num_rows>0){
            $thoiGianBD = '';
            while($row = $ktXemCoDangLamBai->fetch_assoc()){
                $thoiGianBD = $row['batdau'];
            }
            $xoaBaiDangLam = $ketnoi->query("DELETE FROM `dang_lam_bo_de` WHERE `taikhoan`='$user' AND `idbode`='$idDe'");
            $xoaBaiDangLam;
            $dem=0;$dsDA=array();
            foreach($Cau as $da){
                $dsDA[$dem++] = $da;
            }
            $dem=0;
            $tongDiem = 0;
            $layDA = $ketnoi->query("SELECT `ch`.idcauhoi,`ch`.da from `cau_hoi` `ch`,`cauhoi_thuoc_bode` `ctd` WHERE `ch`.idcauhoi=`ctd`.idcauhoi AND `ctd`.idbode = '$idDe'");
            if($layDA && $layDA ->num_rows>0){
                while($row = $layDA->fetch_assoc()){
                    $idCauhoi = $row['idcauhoi'];
                    $xoaCauTLcu = $ketnoi->query("DELETE FROM `tra_loi` WHERE `taikhoan` ='$user' AND `idcauhoi`='$idCauhoi'");
                    $xoaCauTLcu;
                    $themCauTL = $ketnoi->query("INSERT INTO `tra_loi`(`taikhoan`, `idbode`, `idcauhoi`, `da`) VALUES ('$user','$idDe','$idCauhoi','$dsDA[$dem]')");
                    $themCauTL;
                    if($row['da']==$dsDA[$dem++]) $tongDiem++;
                }
                $now = strtotime($now);
                $thoiGianBD = strtotime($thoiGianBD);
                $thoiGianLamTam = $now - $thoiGianBD;
                $thoiGianLam = date("0:i:s", $thoiGianLamTam);
                //date_modify($now,"-".$thoiGianBD);
                //$thoiGianLam = date("i:s", $now);
                $xoaDiemcu = $ketnoi->query("DELETE FROM `diem_so` WHERE `taikhoan` ='$user' AND `idbode`='$idDe'");
                $xoaDiemCu;
                $chamDiem = $ketnoi->query("INSERT INTO `diem_so`(`taikhoan`, `idbode`, `socau`, `tongdiem`,`thoigian`) VALUES ('$user','$idDe','$dem','$tongDiem','$thoiGianLam')");
                $chamDiem;
                $xoaCauTLcu = $ketnoi->query("DELETE FROM `tra_loi` WHERE `taikhoan` ='$user' AND `idbode`='$idDe'");
                $xoaCauTLcu;
                header("Location: ../xem?idbode=$idDe");
            }
        } else {
            header("Location: ../xem?idbode=$idDe");
        }
    }else if($action=='luu'){
        //Luu cau tra loi nhung chua nop
        $ktXemCoDangLamBai = $ketnoi->query("SELECT * FROM `dang_lam_bo_de` WHERE `taikhoan`='$user' AND `idbode`='$idDe'");
        if($ktXemCoDangLamBai && $ktXemCoDangLamBai->num_rows>0){
            //$xoaBaiDangLam = $ketnoi->query("DELETE FROM `dang_lam_bo_de` WHERE `taikhoan`='$user' AND `idbode`='$idDe'");
            //$xoaBaiDangLam;
            $dem=0;$dsDA=array();
            foreach($Cau as $da){
                $dsDA[$dem++] = $da;
            }
            $dem=0;
            $layDA = $ketnoi->query("SELECT `ch`.idcauhoi,`ch`.da from `cau_hoi` `ch`,`cauhoi_thuoc_bode` `ctd` WHERE `ch`.idcauhoi=`ctd`.idcauhoi AND `ctd`.idbode = '$idDe'");
            if($layDA && $layDA ->num_rows>0){
                while($row = $layDA->fetch_assoc()){
                    $idCauhoi = $row['idcauhoi'];
                    $xoaCauTLcu = $ketnoi->query("DELETE FROM `tra_loi` WHERE `taikhoan` ='$user' AND `idcauhoi`='$idCauhoi'");
                    $xoaCauTLcu;
                    $themCauTL = $ketnoi->query("INSERT INTO `tra_loi`(`taikhoan`, `idbode`, `idcauhoi`, `da`) VALUES ('$user','$idDe','$idCauhoi','$dsDA[$dem]')");
                    $themCauTL;
                    $dem++;
                }
                header("Location: ../lam-bai/?idbode=$idDe");
            }
        }
    }
    
} else{
    header('Locate: ../');
}

?>
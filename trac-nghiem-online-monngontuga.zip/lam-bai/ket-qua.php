<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('../meta.php');
    ?>

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php
            include_once('../menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card border border-secondary">
                                    <div class="card-header">
                                        <strong class="card-title">Xem kết quả trắc nghiệm</strong>
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        $idDe = isset($_GET['idbode']) ? $_GET['idbode'] : NULL;
                                        if(!isset($_SESSION['user'])){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Vui lòng đăng nhập để xem kết quả bạn nnhe!
        									</div>';
                                        } else if($idDe==NULL){
                                            $user = $_SESSION['user'];
                                            $layKQ = $ketnoi->query("SELECT * FROM `diem_so` WHERE `taikhoan`='$user'");
                                            if($layKQ && $layKQ->num_rows>0){
                                                while($row=$layKQ->fetch_assoc()){
                                                    echo'...';
                                                }
                                            }
                                        } else if($idDe!=NULL){
                                            $user = $_SESSION['user'];
                                            $layKQ = $ketnoi->query("SELECT * FROM `diem_so` WHERE `taikhoan`='$user' AND `idbode`='$idDe'");
                                            if($layKQ && $layKQ->num_rows>0){
                                                $soCau = 0;
                                                $tongDiem = 0;
                                                $thoiGian = 0;
                                                while($row=$layKQ->fetch_assoc()){
                                                    $soCau = $row['socau'];
                                                    $tongDiem = $row['tongdiem'];
                                                    $thoiGian = $row['thoigian'];
                                                }
                                                $mauSac = '';
                                                $loiNoi = '';
                                                if($tongDiem/$soCau==1){
                                                    $mauSac = 'alert alert-success';
                                                    $loiNoi = 'Quá hay!! Bạn là một trong những người làm đúng';
                                                } else if($tongDiem/$soCau < 1 && $tongDiem/$soCau >=0.8){
                                                    $mauSac = 'alert alert-warning';
                                                    $loiNoi = 'Cũng hay!! Lần sau gáng tròn điểm nhe lần này đúng';
                                                } else if($tongDiem/$soCau < 0.8 && $tongDiem/$soCau >=0.5){
                                                    $mauSac = 'alert alert-info';
                                                    $loiNoi = 'Gáng lên!! Lần sau làm đúng nhiều hơn nhé!!';
                                                } else if($tongDiem/$soCau < 0.5 && $tongDiem/$soCau >=0.3){
                                                    $mauSac = 'alert alert-dark';
                                                    $loiNoi = 'Bạn cần cố gắng nhiều hơn nữa T-T, đúng';
                                                } else  {
                                                    $mauSac = 'alert alert-danger';
                                                    $loiNoi = 'Chèn ơi, làm bài cho tử tế đi chứ có';
                                                }
                                                echo'
                                                <div class="'.$mauSac.' text-center">
                                                    '.$loiNoi.' '.$tongDiem.'/'.$soCau.' câu!!
                                                    <hr>
                                                        Thời gian làm: '.$thoiGian.'
                                                    <hr>
                                                    <a href="../lam-bai/?idbode='.$idDe.'" class="btn btn-primary">
                                                        <i class="fa fa-star"></i>&nbsp; Làm lại
                                                    </a>
                                                </div>';
                                            } else {
                                                echo'
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
            										Bạn chưa làm bộ đề này mà coi cái gì chớ
            									</div>';
                                            }
                                            
                                        }
                                        
                                    ?>
                                
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                            include_once('../footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php
        include_once('../script.php')
    ?>
</body>

</html>
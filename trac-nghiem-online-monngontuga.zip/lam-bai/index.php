<!DOCTYPE html>
<html lang="vi">
<?php
    $executionStartTime = microtime(true);
    $thoiGianKT = '';
    $coLamBai = 0;
    $boDeDangLam = '';
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('../meta.php');
    ?>
    <style>
        .bang-dieu-khien{
            position: sticky;
        }
        .noi{
            position: fixed;
            top: 0;
            right:0;
            z-index:0;
            left: 0;
        }
        .row{
            z-index:1;
        }
        .full{
            left: 0;
            right:0;
        }
    </style>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <?php
            include_once('../menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p15">
                    <div class="container-fluid">
                        <div class="row bang-dieu-khien" id="bangDieuKhien">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                    <strong>Điều khiển </strong>
                                    </div>
                                    <?php
                                    if(!isset($_SESSION['user'])){
                                            echo'
                                            <script>
                                                window.location="../dang-nhap";
                                            </script>
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Vui lòng đăng nhập để làm bài trắc nghiệm  bạn nnhe!
        									</div>';
                                        } else if(isset($_GET['idbode'])){
                                            $idbode = isset($_GET['idbode'])?$_GET['idbode']:'';
                                            echo'
                                            <div class="card-body">
                                                <button onClick="xnNop()" type ="button"class="btn btn-primary btn-xl">
                                                    <i class="fa fa-dot-circle-o"></i> Nộp bài
                                                </button>
                                                <button class="btn btn-success btn-xl" onClick="luuCauTL()">
                                                    <i class="fa fa-save"></i> Lưu bài làm
                                                </button>
                                                <hr>
                                                <p id="demNguocThoiGian2"></p>
                                                ';
                                                
                                            $dem = 0;
                                            $laySoCauHoi_saved = $ketnoi->query("SELECT*FROM `tra_loi` tl join `cauhoi_thuoc_bode` chb on tl.`idcauhoi` = chb.`idcauhoi` WHERE tl.`taikhoan`='$user' AND chb.`idbode`='$idbode'");
                                            $laySoCauHoi = $ketnoi->query("SELECT * FROM `cauhoi_thuoc_bode` WHERE `idbode`='$idbode'");
                                            if($laySoCauHoi_saved && $laySoCauHoi_saved->num_rows>0){
                                                while($inQuaTrinh = $laySoCauHoi_saved->fetch_assoc())
                                                    if($inQuaTrinh['da']!=0)
                                                        echo'<button type="button" class="btn btn-secondary btn-sm" onClick="toiCau('.$inQuaTrinh['idcauhoi'].')" id="nut_'.$inQuaTrinh['idcauhoi'].'">'.++$dem.'</button>';
                                                    else
                                                        echo'<button type="button" class="btn btn-outline-secondary btn-sm" onClick="toiCau('.$inQuaTrinh['idcauhoi'].')" id="nut_'.$inQuaTrinh['idcauhoi'].'">'.++$dem.'</button>';
                                                
                                            }else if($laySoCauHoi && $laySoCauHoi->num_rows>0)
                                                while($inCauHoi = $laySoCauHoi->fetch_assoc())
                                                        echo'<button type="button" class="btn btn-outline-secondary btn-sm" onClick="toiCau('.$inCauHoi['idcauhoi'].')" id="nut_'.$inCauHoi['idcauhoi'].'">'.++$dem.'</button>';
                                             
                                            
                                            echo'    
                                            </div>';
                                        }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="row" id="baiLam">
                            <div class="col-md-12">
                                <div class="card border border-secondary">
                                    <div class="card-header">
                                        <strong class="card-title">Làm trắc nghiệm</strong>
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        if(!isset($_SESSION['user'])){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Vui lòng đăng nhập để làm bài trắc nghiệm  bạn nnhe!
        									</div>';
                                        } else if(!isset($_GET['idbode'])){
                                            echo'
                                            <div class="table-responsive table--no-card m-b-30">
                                            <table class="table table-borderless table-striped table-data3 table-earning">
                                                <thead>
                                                    <tr>
                                                        <th class="text-center col-sm-6 col-lg-4">Tên đề</th>
                                                        <th class="text-center">Số câu hỏi</th>
                                                        <th class="text-center">Thời gian</th>
                                                        <th class="text-center">Số lượt (lần)</th>
                                                        <th class="text-center">Làm bài</th>
                                                    </tr>
                                                </thead>
                                                <tbody>';
                                            $bode = $ketnoi->query("SELECT * FROM `bo_de` ORDER BY `idbode` DESC");
                                            if($bode && $bode->num_rows>0){
                                                while($row = $bode->fetch_assoc()){
                                                    $idbd = $row['idbode'];
                                                    $soLan = $row['solanduocthuchien'];
                                                    if($soLan==0) $soLan="Không giới hạn";
                                                    $socauhoi = $ketnoi->query("SELECT DISTINCT * FROM `bo_de` `bd`, `cauhoi_thuoc_bode` `ctb` WHERE `bd`.idbode=`ctb`.idbode AND `bd`.idbode = '$idbd'");
                                                    echo'
                                                    <tr>
                                                        <td class="col-sm-6 col-lg-4">'.$row['tenbode'].'</td>
                                                        <td class="text-center">'.$socauhoi->num_rows.'</td>
                                                        <td class="text-center">'.$row['thoigian'].' phút</td>
                                                        <td class="text-center">'.$soLan.'</td>
                                                        <td class="text-center"><button class="btn btn-primary btn-sm" onClick="lamDe('.$row['idbode'].')">Làm</button></td>
                                                    </tr>';
                                            }
                                            echo'
                                                </tbody>
                                            </table>
                                            </div>';
                                                }
                                        } else if(isset($_GET['idbode'])){
                                            $idDe = $_GET['idbode'];
                                            $soLan = -1;
                                            $bode = $ketnoi->query("SELECT * FROM `bo_de` WHERE `idbode`='$idDe'");
                                            if($bode && $bode->num_rows == 0){
                                                echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Vui lòng chọn lại đề để làm nhé bạn !
        									</div>';
                                            } else if($bode && $bode->num_rows>0){
                                                $tenDe = '';
                                                $thoiGian = 0;
                                                while($row = $bode->fetch_assoc()){
                                                    $tenDe = $row['tenbode'];
                                                    $thoiGian = $row['thoigian'];
                                                    $soLan=$row['solanduocthuchien'];
                                                }
                                                //Mot luc chi duoc lam mot bo de
                                                $ktXemCoDangLam = $ketnoi->query("SELECT * FROM `dang_lam_bo_de` WHERE `taikhoan`='$user'");
                                                //Lấy số lần user đã làm đề này:
                                                $laySoLanDaLam = $ketnoi->query("SELECT * FROM `diem_so` WHERE `taikhoan`='$user' AND `idbode`='$idDe'");
                                                if($laySoLanDaLam && $laySoLanDaLam->num_rows >= $soLan && $soLan!=0){
                                                    echo '
                                                    <div class="alert alert-danger" role="alert" style="text-align:center">
            											Bạn đã hết lượt làm bộ đề này!!
            										</div>';
                                                }
                                                else 
                                                if($ktXemCoDangLam && $ktXemCoDangLam->num_rows == 0){
                                                    $now = date("Y-m-d H:i:s");
                                                    //$thoiGianKT = strtotime("+".$thoiGian." minutes", strtotime(date("Y-m-d H:i:s")));
                                                    $executionEndTime = microtime(true);
                                                    $executionTime = (int)($executionEndTime-$executionStartTime);
                                                    $thoiGianKT = date("Y-m-d H:i:s", strtotime("+".$thoiGian." minutes ".$executionTime." seconds", strtotime(date("Y-m-d H:i:s"))));
                                                    $dangLam = $ketnoi->query("INSERT INTO `dang_lam_bo_de`(`taikhoan`, `idbode`,`batdau`,`ketthuc`) VALUES ('$user','$idDe','$now','$thoiGianKT')");
                                                    $dangLam;
                                                    $coLamBai = 1;
                                                    $boDeDangLam = $idDe;
                                                    //Tao ra mot moc thoi gian lam bai moi
                                                } else if ($ktXemCoDangLam && $ktXemCoDangLam->num_rows > 0){
                                                    while($row = $ktXemCoDangLam->fetch_assoc()){
                                                        $thoiGianKT = $row['ketthuc'];
                                                        $boDeDangLam = $row['idbode'];
                                                    }
                                                    $coLamBai = 1;
                                                }
                                                if($idDe == $boDeDangLam){
                                                    $layCauHoi = $ketnoi->query("SELECT DISTINCT * FROM `bo_de` `bd`, `cauhoi_thuoc_bode` `ctb`, `cau_hoi` `ch` WHERE `bd`.idbode = `ctb`.idbode AND `ctb`.idcauhoi = `ch`.idcauhoi AND `bd`.idbode = '$idDe'");
                                                    if($layCauHoi && $layCauHoi->num_rows>0){
                                                        $dem = 1;
                                                        echo '<form id="baiLam" method="post" action="cham-bai.php?action=nop">';
                                                        echo '<input name="debai" value="'.$idDe.'" hidden/>';
                                                        while($row = $layCauHoi->fetch_assoc()){
                                                            $A = '';$B = '';$C = '';$D = '';
                                                            $idCH = $row['idcauhoi'];
                                                            $layCauTLDaLuu = $ketnoi->query("SELECT * FROM `tra_loi` WHERE `idcauhoi`='$idCH' AND `taikhoan`='$user'");
                                                            if($layCauTLDaLuu && $layCauTLDaLuu->num_rows>0){
                                                                while($dapAnTam = $layCauTLDaLuu->fetch_assoc()){
                                                                    if($dapAnTam['da']==1) 
                                                                        $A = 'checked';
                                                                    else if($dapAnTam['da']==2) 
                                                                        $B = 'checked';
                                                                    else if($dapAnTam['da']==3) 
                                                                        $C = 'checked';
                                                                    else if ($dapAnTam['da']==4) 
                                                                        $D = 'checked';
                                                                }
                                                            }
                                                            
                                                            echo'
                                                            <div class="col col-lg-12">
                                                                <section class="card">
                                                                  <div class="card-body text-secondary">
                                                                      <div class="col-lg-12" id="'.$row['idcauhoi'].'">
                                                                        <b>Câu '.$dem.': '.$row['cauhoi'].'</b>
                                                                      </div>
                                                                      <div class="col-lg-12">
                                                                        <label for="Cau'.$dem.'a" class="form-check-label ">
                                                                            <input checked type="radio" name="Cau['.$dem.']" value="0" hidden>
                                                                            <input onClick="chonCauTL('.$row['idcauhoi'].')" '.$A.' required type="radio" id="Cau'.$dem.'a" name="Cau['.$dem.']" value="1" class="form-check-input">A. '.$row['a'].'
                                                                        </label>
                                                                      </div>
                                                                      <div class="col-lg-12">
                                                                        <label for="Cau'.$dem.'b" class="form-check-label ">
                                                                            <input onClick="chonCauTL('.$row['idcauhoi'].')" '.$B.' required type="radio" id="Cau'.$dem.'b" name="Cau['.$dem.']" value="2" class="form-check-input">B. '.$row['b'].'
                                                                        </label>                                                                  </div>
                                                                      <div class="col-lg-12">
                                                                        <label for="Cau'.$dem.'c" class="form-check-label ">
                                                                            <input onClick="chonCauTL('.$row['idcauhoi'].')" '.$C.' required type="radio" id="Cau'.$dem.'c" name="Cau['.$dem.']" value="3" class="form-check-input">C. '.$row['c'].'
                                                                        </label>                                                                  </div>
                                                                      <div class="col-lg-12">
                                                                        <label for="Cau'.$dem.'d" class="form-check-label ">
                                                                            <input onClick="chonCauTL('.$row['idcauhoi'].')" '.$D.' required type="radio" id="Cau'.$dem.'d" name="Cau['.$dem++.']" value="4" class="form-check-input">D. '.$row['d'].'
                                                                        </label>                                                                  </div>
                                                                  </div>
                                                                </section>
                                                            </div>
                                                            ';
                                                        }
                                                        echo '</form>';
                                                    }
                                                } else if($coLamBai==1){
                                                    echo '
                                                    <div class="alert alert-danger" role="alert" style="text-align:center">
            											Một lúc chỉ được làm 1 bộ đề thoi bạn ui!! Quay về đề đang làm là <a href ="../xem/?idbode='.$boDeDangLam.'">Đề có mã '.$boDeDangLam.'</a> đi, sắp hết thời gian ời kìa
            										</div>';
            										$coLamBai = 0;
                                                }
                                                
                                            }
                                        }
                                        
                                    ?>
                                
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                            include_once('../footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php
        include_once('../script.php')
    ?>
    <script>
    <?php
        if($coLamBai==1){
            echo'    
    function xnNop(){
        swal("Nộp hen?", {
                icon: "warning",
                buttons: {
                      nop : "Nộp!!!",
                      cancle:"Chưa nộp!"
                  },
            })
            .then((value)=>{
                switch (value) {
                    case "nop":
                      nopBai();
                      break;
                 
                    default:
                        swal("Hông nộp thì lo làm đi 3!!");
                }
            });
    }
    function luuCauTL(){
        document.forms["baiLam"].action="cham-bai.php?action=luu";
        document.forms["baiLam"].submit();
    }
    function nopBai(){
        document.forms["baiLam"].action="cham-bai.php?action=nop";
        document.forms["baiLam"].submit();
    }
    var demNguoc = new Date("'.$thoiGianKT.'").getTime();
    var x = setInterval(function() {
          var now = new Date().getTime();
          var distance = demNguoc - now;
          var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
          var seconds = Math.floor((distance % (1000 * 60)) / 1000);
          //document.getElementById("demNguocThoiGian1").innerHTML ="Thời gian còn "+minutes + " phút " + seconds + " giây";
          document.getElementById("demNguocThoiGian2").innerHTML ="Thời gian còn "+minutes + " phút " + seconds + " giây";
          if (distance < 0) {
            clearInterval(x);
            //document.getElementById("demNguocThoiGian1").innerHTML = "HẾT THỜI GIAN!";
            document.getElementById("demNguocThoiGian2").innerHTML = "HẾT THỜI GIAN!";
            nopBai();
          }
    }, 1000);
                ';
        }
    ?>
    </script>
    <script>
    function toiCau(idcauhoi){
        var $window = $(window),
        $element = $("#"+idcauhoi),
        elementTop = $element.offset().top,
        elementHeight = $element.height(),
        viewportHeight = $window.height(),
        scrollIt = elementTop - ((viewportHeight - elementHeight) / 2);
    
        $window.scrollTop(scrollIt);
    }
    function chonCauTL(idcauhoi){
        var nut = document.getElementById("nut_"+idcauhoi);
        nut.classList.remove("btn-outline-secondary");
        nut.classList.add("btn-secondary");
    }
    window.onscroll = function(){noiLenTren()};
    
    var bdk = document.getElementById("bangDieuKhien");
    var sticky = bdk.offsetTop;
    var baiLam = document.getElementById("baiLam");
    
    function noiLenTren() {
        if (window.pageYOffset > sticky){
            bdk.classList.add("noi");
            baiLam.classList.add("full");
        }
        else{
            bdk.classList.remove("noi");
            baiLam.classList.remove("full");
        }
            
    }
</script>
</body>
<script>
    function lamDe(idbode){window.location="../xem/?idbode="+idbode;}
</script>
</html>

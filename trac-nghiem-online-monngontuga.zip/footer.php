<div class="row">
    <div class="col-md-12">
                                <div class="copyright">
                                    <p>By Vu with <i class="fa fa-heart"></i>. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
                                </div>
                            </div>
</div>
                            
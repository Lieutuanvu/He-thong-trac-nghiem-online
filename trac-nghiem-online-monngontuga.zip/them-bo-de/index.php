<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('../meta.php');
    ?>

</head>
<body class="animsition">
    <div class="page-wrapper">
        <?php
            include_once('../menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card border border-secondary">
                                    <div class="card-header">
                                        <strong class="card-title">Thêm bộ đề</strong>
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        if(!isset($_SESSION['user']) || $user!='lieutuanvu'){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Khu vực chỉ dành cho admin
        									</div>';
        									echo'
                                             <script>
                                             window.location="../dang-nhap";
                                             </script>';
                                        } else {
                                            /////Phan nay xu ly them cau hoi
                                            $tenDe = isset($_POST['tenDe']) ? $_POST['tenDe']:'';
                                            $thoiGian = isset($_POST['thoiGian']) ? $_POST['thoiGian']:'';
                                            $soLan = isset($_POST['solan']) ? $_POST['solan']:'';
                                            if($tenDe!='' && $thoiGian!='' && $soLan!=''){
                                                $themBoDe = $ketnoi->query("INSERT INTO `bo_de`(`tenbode`, `thoigian`,`solanduocthuchien`) VALUES ('$tenDe','$thoiGian','$soLan')");
                                                $themBoDe;
                                                echo'
                                                <script>
                                                    window.location="../them-bo-de";
                                                </script>';
                                                //header('Location: ../them-bo-de');
                                            }        
                                            //////Phan duoi hien thi form them cau hoi
                                            echo'
                                            <form action="" method="post" class="">
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-file"></i>
                                                        </div>
                                                        <input required type="text" name="tenDe" placeholder="Tên đề" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-clock-o"></i>
                                                        </div>
                                                        <input required max="120" min="1" type="number" name="thoiGian" placeholder="Thời gian (phút)" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="row form-group">
                                                    <div class="col col-md-2">
                                                        <label class=" form-control-label">Số lần được thực hiện:</label>
                                                    </div>
                                                    <div class="col col-md-9">
                                                        <div class="form-check">
                                                            <div class="radio">
                                                                <label for="1lan" class="form-check-label ">
                                                                    <input required type="radio" id="1lan" name="solan" value="1" class="form-check-input">Chỉ 1 lần
                                                                </label>
                                                            </div>
                                                            <div class="radio">
                                                                <label for="0lan" class="form-check-label ">
                                                                    <input required type="radio" id="0lan" name="solan" value="0" class="form-check-input">Không giới hạn
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-footer">
                                                    <div class="form-actions form-group">
                                                        <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                            ';
                                        }
                                    ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                            include_once('../footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php
        include_once('../script.php')
    ?>
</body>

</html>

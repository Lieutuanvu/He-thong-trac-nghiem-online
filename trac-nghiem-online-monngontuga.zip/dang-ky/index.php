<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Hệ thống làm bài trăc nghiệm Món ngon từ gà">
    <meta name="author" content="LieuTuanVu">
    <meta name="keywords" content="Hệ thống làm bài trăc nghiệm Món ngon từ gà, món ngon từ gà, món ngon, gà, từ gà, món ăn, trắc nghiệm, làm bài trắc nghiệm, trắc nghiệm online, gà online, trắc nghiệm gà, gà trắc nghiệm">
    <title>Đăng ký - Hệ thống làm bài trăc nghiệm</title>
    <link href="../css/font-face.css" rel="stylesheet" media="all">
    <link href="../vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <link href="../vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="../vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="../vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="../vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <link href="../css/theme.css" rel="stylesheet" media="all">

</head>
<body class="animsition">
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="#">
                                <h3>Hệ thống làm bài trắc nghiệm</h3>
                            </a>
                        </div>
                        <div class="login-form">
                            <form action="../dang-ky/index.php" method="post">
                                <?php
                                    $taikhoan = isset($_POST['taikhoan']) ? strtolower($_POST['taikhoan']) : '';
                                    $hoten = isset($_POST['hoten']) ? $_POST['hoten'] : '';
                                    $matkhau = isset($_POST['matkhau']) ? $_POST['matkhau'] : '';
                                    if($taikhoan=='' && $hoten=='' && $matkhau==''){
                                        echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Nhập tài khoản, họ tên với mật khẩu để đăng ký
        										</div>';
                                    }
                                    else if($taikhoan!='' && $hoten=='' && $matkhau==''){
                                        echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Chèn ơi nhập họ tên với mật khẩu đi
        										</div>';
                                    }
                                    else if($taikhoan!='' && $hoten!='' && $matkhau==''){
                                        echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Chèn ơi nhập mật khẩu đi
        										</div>';
                                    }
                                    else if($taikhoan!='' && $hoten=='' && $matkhau!=''){
                                        echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Chèn ơi nhập họ tên đi
        										</div>';
                                    }
                                    else if($taikhoan=='' && $hoten=='' && $matkhau!=''){
                                        echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Chèn ơi nhập tài khoản với họ tên đi
        										</div>';
                                    }
                                    else if($taikhoan=='' && $hoten!='' && $matkhau==''){
                                        echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Chèn ơi nhập tài khoản với mật khẩu đi
        										</div>';
                                    }
                                    else if($taikhoan=='' && $hoten!='' && $matkhau!=''){
                                        echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Chèn ơi nhập tài khoản đi
        										</div>';
                                    }
                                    else if($taikhoan!='' && $hoten!='' && $matkhau!=''){
                                        $matkhau = md5($matkhau);
                                        $trave = $ketnoi->query("SELECT * FROM `tai_khoan` WHERE `taikhoan`='$taikhoan'");
                                        if($trave && $trave->num_rows==0){
                                            $dangky = $ketnoi->query("INSERT INTO `tai_khoan`(`taikhoan`, `matkhau`, `hoten`) VALUES ('$taikhoan','$matkhau','$hoten')");
                                            if($dangky){
                                                echo '
                                                <div class="text-center sufee-alert alert with-close alert-success alert-dismissible fade show">
        											<span class="badge badge-pill badge-success">Đăng ký thành công</span>
        											    Đăng nhập để làm bài nhenn</br>Tự động chuyển đến trang đăng nhập trong 3s
        										</div>';
        									    header("Refresh:3; url=../dang-nhap", true, 303);
                                            }
                                        } else{
                                            echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Tài khoản đã tồn tại ùi!!
        										</div>';
                                        }
                                    }
                                ?>
                                <div class="form-group">
                                    <label>Tài khoản</label>
                                    <input class="au-input au-input--full" maxlength="10" type="text" name="taikhoan" placeholder="Tài khoản tối đa 10 ký tự">
                                </div>
                                <div class="form-group">
                                    <label>Họ tên</label>
                                    <input class="au-input au-input--full" type="text" name="hoten" placeholder="Họ tên">
                                </div>
                                <div class="form-group">
                                    <label>Mật khẩu</label>
                                    <input class="au-input au-input--full" type="password" name="matkhau" placeholder="Mật khẩu">
                                </div>
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">Đăng ký</button>
                            </form>
                            <div class="register-link">
                                <p>
                                    Đăng ký rồi đúng hông?
                                    <a href="../dang-nhap">Đăng nhập ở đây nà</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <script src="../vendor/jquery-3.2.1.min.js"></script>
    <script src="../vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="../vendor/wow/wow.min.js"></script>
    <script src="../vendor/animsition/animsition.min.js"></script>
    <script src="../vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="../vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="../vendor/circle-progress/circle-progress.min.js"></script>
    <script src="../vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="../vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="../vendor/select2/select2.min.js">
    </script>
    <script src="../js/main.js"></script>

</body>

</html>
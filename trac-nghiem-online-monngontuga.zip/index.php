<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = (isset($_SESSION['user']))?$_SESSION['user']:'';
    if($user=='') $_SESSION['xacThuc']=2;
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('meta.php');
    ?>
</head>
<body class="animsition">
    <div class="page-wrapper">
        <?php
            include_once('menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row m-t-25">
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item overview-item--c1">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php
                                                    $laySoThanhVien = $ketnoi->query("SELECT * from `tai_khoan` WHERE `blocked`<>1");
                                                    $laySoThanhVien;
                                                    echo $laySoThanhVien->num_rows;
                                                ?>
                                                </h2>
                                                <span>thành viên</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item overview-item--c2">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-view-list-alt"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php
                                                    $laySoBoDe = $ketnoi->query("SELECT * from `bo_de`");
                                                    $laySoBoDe;
                                                    echo $laySoBoDe->num_rows;
                                                ?>
                                                </h2>
                                                <span>bộ đề</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item overview-item--c3">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-help"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php
                                                    $laySoCauHoi = $ketnoi->query("SELECT * from `cau_hoi`");
                                                    $laySoCauHoi;
                                                    echo $laySoCauHoi->num_rows;
                                                ?>
                                                </h2>
                                                <span>câu hỏi</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card border border-secondary">
                                    <div class="card-header">
                                        <strong class="card-title">Các bộ đề</strong>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-data3 table-earning">
                                        <thead>
                                    
                                            <tr>
                                                <th class="text-center col-sm-6 col-lg-4">Tên đề</th>
                                                <th class="text-center">Số câu hỏi</th>
                                                <th class="text-center">Thời gian</th>
                                                <th class="text-center">Số lượt (lần)</th>
                                                <th class="text-center">Làm bài</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                    <?php
                                        $bode = $ketnoi->query("SELECT * FROM `bo_de` ORDER BY `idbode` DESC");
                                        if($bode && $bode->num_rows>0){
                                            while($row = $bode->fetch_assoc()){
                                                $idbd = $row['idbode'];
                                                $soLan = $row['solanduocthuchien'];
                                                if($soLan==0) $soLan="Không giới hạn";
                                                $socauhoi = $ketnoi->query("SELECT DISTINCT * FROM `bo_de` `bd`, `cauhoi_thuoc_bode` `ctb` WHERE `bd`.idbode=`ctb`.idbode AND `bd`.idbode = '$idbd'");
                                                echo'
                                                <tr>
                                                    <td class="col-sm-6 col-lg-4">'.$row['tenbode'].'</td>
                                                    <td class="text-center">'.$socauhoi->num_rows.'</td>
                                                    <td class="text-center">'.$row['thoigian'].' phút</td>
                                                    <td class="text-center">'.$soLan.'</td>
                                                    <td class="text-center"><button class="btn btn-primary btn-sm" onClick="lamDe('.$row['idbode'].')">Làm</button></td>
                                                </tr>';
                                            }
                                        }
                                    ?>
                                        </tbody>
                                    </table>
                                </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                            include_once('footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
        include_once('script.php')
    ?>
</body>
<script>
    function lamDe(idbode){window.location="../xem/?idbode="+idbode;}
</script>
</html>

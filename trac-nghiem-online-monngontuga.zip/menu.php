<header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="../">
                            <img src="../images/icon/logo.png" alt="MonNgonTuGa" />
                        </a>
                        <button type="button" class="hamburger hamburger--slider"><a href="#" class="btn btn-primary">MENU</a></button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li>
                            <a class="js-arrow" href="../">
                                <i class="fas fa-tachometer-alt"></i>Home</a>
                        </li>
                        <li>
                            <a class="js-arrow" href="../bang-xep-hang">
                                <i class="zmdi zmdi-chart"></i>Bảng xếp hạng</a>
                        </li>
                <?php
                    if(isset($_SESSION['user'])){
                        $user = $_SESSION['user'];
                        $tenUser = '';
                        $UserAVT = '';
                        $layTen = $ketnoi->query("SELECT * FROM `tai_khoan` WHERE `taikhoan`='$user'");
                        if($layTen && $layTen->num_rows>0){
                            while($row = $layTen->fetch_assoc()){
                                $tenUser = $row['hoten'];
                                $UserAVT = $row['avt'];
                            }
                        }
                        echo'
                        <script>
                        function xemThongTin(){
                            window.location="../thong-tin-thanh-vien";
                        }
                        </script>
                        <div onClick="xemThongTin()" class="account-item clearfix js-item-menu">
                            <div class="image">
                                <img class="img rounded" src="../images/avt/'.$UserAVT.'" alt="'.$tenUser.'">
                            </div>
                            <div class="content">
                                <a class="js-arrow" href="../thong-tin-thanh-vien">Hello '.$tenUser.'</a>
                            </div>
                        </div>';
                        if($user=='lieutuanvu')
                            echo'
                            <li>
                                <a class="js-arrow" href="../quan-ly-thanh-vien">
                                    <i class="fas fa-user"></i>Quản lý thành viên
                                </a>
                            </li>
                            <li class="has-sub">
                                <a class="js-arrow" href="#">
                                    <i class="fas fa-bars"></i>Ra đề và quản lý
                                </a>
                                <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                    <li>
                                        <a href="../them-bo-de">Thêm bộ đề </a>
                                    </li>
                                    <li>
                                        <a href="../quan-ly-bo-de">Quản lý bộ đề </a>
                                    </li>
                                    <li>
                                        <a href="../them-cau-hoi">Thêm câu hỏi</a>
                                    </li>
                                    <li>
                                        <a href="../quan-ly-cau-hoi">Quản lý câu hỏi</a>
                                    </li>
                                </ul>
                            </li>';
                        echo'
                        <li>
                            <a class="js-arrow" href="../dang-xuat">
                                <i class="zmdi zmdi-power"></i>Thoát</a>
                        </li>';
                    } else {
                        echo'
                        <li>
                            <a class="js-arrow" href="../dang-nhap">
                                <i class="zmdi zmdi-account"></i>Đăng nhập</a>
                        </li>';
                    }
                ?>
                    </ul>
                </div>
            </nav>
        </header>
        <aside class="menu-sidebar d-none d-lg-block" id="menu-web">
            <div class="logo">
                <a href="../">
                            <img src="../images/icon/logo.png" alt="MonNgonTuGa" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a class="js-arrow" href="../">
                                <i class="fas fa-tachometer-alt"></i>Home</a>
                        </li>
                        <li>
                            <a class="js-arrow" href="../bang-xep-hang">
                                <i class="zmdi zmdi-chart"></i>Bảng xếp hạng</a>
                        </li>
                <?php
                    if(isset($_SESSION['user'])){
                        $user = $_SESSION['user'];
                        $tenUser = '';
                        $UserAVT = '';
                        $layTen = $ketnoi->query("SELECT * FROM `tai_khoan` WHERE `taikhoan`='$user'");
                        if($layTen && $layTen->num_rows>0){
                            while($row = $layTen->fetch_assoc()){
                                $tenUser = $row['hoten'];
                                $UserAVT = $row['avt'];
                            }
                        }
                        echo'
                        <script>
                        function xemThongTin(){
                            window.location="../thong-tin-thanh-vien";
                        }
                        </script>
                        <div onClick="xemThongTin()" class="account-item clearfix js-item-menu">
                            <div class="image">
                                <img class="img rounded" width="35px" height="35px" src="../images/avt/'.$UserAVT.'" alt="'.$tenUser.'">
                            </div>
                            <div class="content">
                                <a class="js-arrow" href="../thong-tin-thanh-vien">Hello '.$tenUser.'</a>
                            </div>
                        </div>';
                        if($user=='lieutuanvu')
                            echo'
                            <li>
                                <a class="js-arrow" href="../quan-ly-thanh-vien">
                                    <i class="fas fa-user"></i>Quản lý thành viên
                                </a>
                            </li>
                            <li class="has-sub">
                                <a class="js-arrow" href="#">
                                    <i class="fas fa-bars"></i>Ra đề và quản lý
                                </a>
                                <ul class="list-unstyled navbar__sub-list js-sub-list" style="display: none;">
                                    <li>
                                        <a href="../them-bo-de">Thêm bộ đề </a>
                                    </li>
                                    <li>
                                        <a href="../quan-ly-bo-de">Quản lý bộ đề </a>
                                    </li>
                                    <li>
                                        <a href="../them-cau-hoi">Thêm câu hỏi</a>
                                    </li>
                                    <li>
                                        <a href="../quan-ly-cau-hoi">Quản lý câu hỏi</a>
                                    </li>
                                </ul>
                            </li>';
                        echo'
                        <li>
                            <a class="js-arrow" href="../dang-xuat">
                                <i class="zmdi zmdi-power"></i>Thoát</a>
                        </li>';
                    } else {
                        echo'
                        <li>
                            <a class="js-arrow" href="../dang-nhap">
                                <i class="zmdi zmdi-account"></i>Đăng nhập</a>
                        </li>';
                    }
                ?>
                        <li>
                            <p id="demNguocThoiGian1"></p>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
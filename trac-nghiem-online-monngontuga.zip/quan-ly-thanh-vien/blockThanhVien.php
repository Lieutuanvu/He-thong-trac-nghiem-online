<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
<?php
                                        if(!isset($_GET['taikhoan']) || !isset($_SESSION['user']) || $user!='lieutuanvu'){
                                            header('Location: ../quan-ly-thanh-vien');
                                        } else {
                                            $taiKhoan = isset($_GET['taikhoan']) ? $_GET['taikhoan'] :'';
                                            if($taiKhoan!='' && $taiKhoan !="lieutuanvu"){
                                                $blockTaiKhoan = $ketnoi->query("UPDATE `tai_khoan` SET `blocked`=1 WHERE `taikhoan`='$taiKhoan'");
                                                if($blockTaiKhoan) echo 'blocked'; 
                                                else echo 'error';
                                            } else {
                                                echo 'error';
                                            }
                                        }
                                    ?>
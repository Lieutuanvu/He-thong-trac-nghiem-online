<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('../meta.php');
    ?>
</head>
<body class="animsition">
    <div class="page-wrapper">
        <?php
            include_once('../menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr class="text-center">
                                                <th>STT</th>
                                                <th>Tài khoản</th>
                                                <th>Họ tên</th>
                                                <th>Trạng thái</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        if(!isset($_SESSION['user']) || $user!='lieutuanvu'){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Khu vực chỉ dành cho admin
        									</div>';
        									echo'
                                            <script>
                                                window.location="../dang-nhap";
                                            </script>';
                                        } else{
                                                $i=1;
                                                $layUser = $ketnoi->query("SELECT * FROM `tai_khoan`");
                                                if($layUser && $layUser->num_rows>0){
                                                    while($row = $layUser->fetch_assoc()){
                                                        $block = '<span class="badge badge-primary">Bình thường</span>';
                                                        if($row['blocked']==1) $block = '<span class='."'".'badge badge-danger'."'".'>Bị block ùi</span>';
                                                        echo'
                                                        <tr class="tr-shadow text-center">
                                                            <td>'.$i++.'</td>
                                                            <td>'.$row['taikhoan'].'</td>
                                                            <td>'.$row['hoten'].'</td>
                                                            <td id="'.$row['taikhoan'].'">'.$block.'</td>
                                                            <td>
                                                                <div class="table-data-feature">
                                                                    <button class="item" data-placement="top" data-toggle="modal" title="Khóa tài khoản này" onClick="block('."'".$row['taikhoan']."'".')">
                                                                        <i class="zmdi zmdi-block"></i>
                                                                    </button>
                                                                    <button class="item" data-placement="top" data-toggle="modal" title="Mở khóa tài khoản này" onClick="unblock('."'".$row['taikhoan']."'".')">
                                                                        <i class="zmdi zmdi-sun"></i>
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr class="spacer"></tr>';
                                                    }
                                                }
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php
                            include_once('../footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal medium -->
			<div class="modal fade" id="suaCauHoi" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Sửa câu hỏi</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body" id="chiTietCauHoi">
						</div>
					</div>
				</div>
			</div>
			<!-- end modal medium -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.0.js"></script>
    <script>
    <?php
    if($user=='lieutuanvu'){
    echo'
    function khoa(taikhoan){
        $.get("blockThanhVien.php?taikhoan="+taikhoan, function(data){
            if(data=="blocked"){
                swal("Đã khóa!", taikhoan+" đã bị block!", "success");
                document.getElementById(taikhoan).innerHTML = "<span class='."'".'badge badge-danger'."'".'>Bị block ùi</span>";
            }
            else
                swal("Lỗi!", "Bị lỗi gì ùi! Để sửa sau", "error");
          });
    }
    function mokhoa(taikhoan){
        $.get("unblockThanhVien.php?taikhoan="+taikhoan, function(data){
            if(data=="unblocked"){
                swal("Đã mở khóa!!", taikhoan+" đã được unblock!", "success");
                document.getElementById(taikhoan).innerHTML = "<span class='."'".'badge badge-primary'."'".'>Bình thường</span>";
            }else
                swal("Lỗi!", "Bị lỗi gì ùi! Để sửa sau", "error");
            });
    }
    function block(taikhoan){
        var trangThai = document.getElementById(taikhoan).innerText;
        var cB = "Bị block ùi";
        if(trangThai.localeCompare(cB)==0)
            swal("Lỗi!", "Tài khoản "+taikhoan+" bị khóa trước đó ời", "error");
        else
            swal("Thiệt sự muốn khóa tài khoản "+ taikhoan +" sao??", {
                icon: "warning",
                buttons: {
                      block : "Khóa đi!!!",
                      cancle:"Hông khóa nữa!"
                  },
            })
            .then((value)=>{
                switch (value) {
                    case "block":
                      khoa(taikhoan);
                      break;
                 
                    default:
                        swal("Okk hông khóa!");
                }
            });
    }
    function unblock(taikhoan){
        var trangThai = document.getElementById(taikhoan).innerText;
        var cB = "Bình thường";
        if(trangThai.localeCompare(cB)==0)
            swal("Lỗi!", "Tài khoản "+taikhoan+" đâu có bị khóa đâu", "error");
        else
            swal("Thiệt sự muốn mở khóa tài khoản "+ taikhoan +" sao??", {
                icon: "warning",
                buttons: {
                      unblock : "Mở khóa đi!!!",
                      cancle:"Hông mở khóa nữa!"
                  },
            })
            .then((value)=>{
                switch (value) {
                    case "unblock":
                      mokhoa(taikhoan);
                      break;
                 
                    default:
                        swal("Okk hông mở khóa!");
                }
            });
    }';
    }
    ?>
    
    </script>

    <?php
        include_once('../script.php')
    ?>
</body>

</html>

<html >
<?php
    include_once('csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = (isset($_SESSION['user']))?$_SESSION['user']:'';
    if($user=='') $_SESSION['xacThuc']=2;
?>
<body>
    <div id="noiDung"></div>
</body>
</html>
<script>

    $("#noiDung").load("index.php");
</script>
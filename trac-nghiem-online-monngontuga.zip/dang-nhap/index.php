<!DOCTYPE html>
<html lang="vi">
<?php
function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}
?>
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Hệ thống làm bài trăc nghiệm Món ngon từ gà">
    <meta name="author" content="LieuTuanVu">
    <meta name="keywords" content="Hệ thống làm bài trăc nghiệm Món ngon từ gà, món ngon từ gà, món ngon, gà, từ gà, món ăn, trắc nghiệm, làm bài trắc nghiệm, trắc nghiệm online, gà online, trắc nghiệm gà, gà trắc nghiệm">
    <title>Đăng nhập - Hệ thống làm bài trắc nghiệm</title>
    <link href="../css/font-face.css" rel="stylesheet" media="all">
    <link href="../vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <link href="../vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="../vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="../vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="../vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <link href="../css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="#">
                                <h3>Hệ thống làm bài trắc nghiệm</h3>
                            </a>
                        </div>
                        <div class="login-form">
                            <form action="../dang-nhap/index.php" method="post">
                            <?php
                                if($user==''){        
                                    $taikhoan = isset($_POST['taikhoan']) ? strtolower($_POST['taikhoan']) : '';
                                    $matkhau = isset($_POST['matkhau']) ? $_POST['matkhau'] : '';
                                    if($taikhoan=='' && $matkhau==''){
                                        echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Nhập tài khoản với mật khẩu để đăng nhập!!
        										</div>';
                                    }
                                    else if($taikhoan!='' && $matkhau==''){
                                        echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Chèn ơi nhập mật khẩu đi
        										</div>';
                                    }
                                    else if($taikhoan=='' && $matkhau!=''){
                                        echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Chèn ơi nhập tài khoản đi
        										</div>';
                                    }
                                    else if($taikhoan!='' && $matkhau!='' && $user==''){
                                        $matkhau = md5($matkhau);
                                        $trave = $ketnoi->query("SELECT * FROM `tai_khoan` WHERE `taikhoan`='$taikhoan'");
                                        if($trave && $trave->num_rows>0){
                                            $tk="";
                                            $mk="";
                                            $block=0;
                                            while($row = $trave->fetch_assoc()){
                                                $tk = $row['taikhoan'];
                                                $mk = $row['matkhau'];
                                                $block = $row['blocked'];
                                            }
                                            if($block==1)
                                                echo '
                                                    <div class="alert alert-danger" role="alert" style="text-align:center">
            											Tài khoản của bạn bị khóa ùi nhen!!
            										</div>';
                                            else if($taikhoan == $tk && $matkhau == $mk){
                                                $_SESSION['user']=$taikhoan;
                                                $user = $_SESSION['user'];
                                                //Đăng nhập thành công, lấy thông tin ra để hiển thị chào
                                                $layTen = $ketnoi->query("SELECT * FROM `tai_khoan` WHERE `taikhoan`='$user'");
                                                if($layTen && $layTen->num_rows>0){
                                                    while($row = $layTen->fetch_assoc()){
                                                        $tenUser = $row['hoten'];
                                                        $UserAVT = $row['avt'];
                                                        $xacThuc = $row['da_xac_thuc'];
                                                        $biKhoa = $row['blocked'];
                                                    }
                                                }
                                                $_SESSION['xacThuc']=$xacThuc;
                                                $_SESSION['biKhoa']=$biKhoa;
                                                $ipaddress = get_client_ip();
                                                $thoiDiem = date("Y-m-d H:i:s");
                                                $logDN=$ketnoi->query("INSERT INTO `log_dang_nhap`(`taikhoan`, `ip`, `thoidiem`) VALUES ('$user','$ipaddress','$thoiDiem')");
                                                $logDN;
                                                echo'
                                                <div class="col-md-12">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <div class="mx-auto d-block">
                                                                <img  width="100px" height="100px" class="rounded-circle mx-auto d-block" src="../images/avt/'.$UserAVT.'" alt="'.$tenUser.'">
                                                                <h5 href="../thong-tin-thanh-vien" class="text-center">Xin chào '.$tenUser.'</h5>
                                                            </div>
                                                            <hr>
                                                            <div class="card-text text-sm-center">
                                                                <button onClick="dieuHuong(1)" type="button" class="btn btn-outline-primary btn-lg btn-block">Home</button>
                                                                <button onClick="dieuHuong(2)" type="button" class="btn btn-outline-primary btn-lg btn-block">Làm trắc nghiệm</button>
                                                                <button onClick="dieuHuong(3)" type="button" class="btn btn-outline-primary btn-lg btn-block">Sửa thông tin</button>
                                                                <button onClick="dieuHuong(4)" type="button" class="btn btn-outline-danger btn-lg btn-block">Đăng xuất</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>';
                                                echo'
                                                <script>window.location="../dang-nhap";</script>';
                                            } else{
                                                echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Sai mật khẩu ùi!!
        										</div>';
                                            }
                                            
                                        } else{
                                            echo '
                                                <div class="alert alert-danger" role="alert" style="text-align:center">
        											Sai tài khoản ùi!!
        										</div>';
                                        }
                                    }
                                } else {
                                            //Đăng nhập thành công, lấy thông tin ra để hiển thị chào
                                                $layTen = $ketnoi->query("SELECT * FROM `tai_khoan` WHERE `taikhoan`='$user'");
                                                if($layTen && $layTen->num_rows>0){
                                                    while($row = $layTen->fetch_assoc()){
                                                        $tenUser = $row['hoten'];
                                                        $UserAVT = $row['avt'];
                                                    }
                                                }
                                                echo'
                                                <div class="col-md-12">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <div class="mx-auto d-block">
                                                                <img  width="100px" height="100px" class="rounded-circle mx-auto d-block" src="../images/avt/'.$UserAVT.'" alt="'.$tenUser.'">
                                                                <h5 href="../thong-tin-thanh-vien" class="text-center">Xin chào '.$tenUser.'</h5>
                                                            </div>
                                                            <hr>
                                                            <div class="card-text text-sm-center">
                                                                <button onClick="dieuHuong(1)" type="button" class="btn btn-outline-primary btn-lg btn-block">Home</button>
                                                                <button onClick="dieuHuong(2)" type="button" class="btn btn-outline-primary btn-lg btn-block">Làm trắc nghiệm</button>
                                                                <button onClick="dieuHuong(3)" type="button" class="btn btn-outline-primary btn-lg btn-block">Sửa thông tin</button>
                                                                <button onClick="dieuHuong(4)" type="button" class="btn btn-outline-danger btn-lg btn-block">Đăng xuất</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>';
                                }
                            ?>
                        <?php
                            if($user=='')
                                echo'
                                <div class="form-group">
                                    <label>Tài khoản</label>
                                    <input class="au-input au-input--full" type="text" name="taikhoan" placeholder="Tài khoản">
                                </div>
                                <div class="form-group">
                                    <label>Mật khẩu</label>
                                    <input class="au-input au-input--full" type="password" name="matkhau" placeholder="Mật khẩu">
                                </div>
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">Đăng nhập</button>';
                        ?>
                            </form>
                        <?php
                            if($user=='')
                                echo'
                            <div class="register-link">
                                <p>
                                    Bạn chưa có tài khoản hả?
                                    <a href="../dang-ky">Đăng ký ở đây nà</a>';
                        ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="../vendor/jquery-3.2.1.min.js"></script>
    <script src="../vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="../vendor/wow/wow.min.js"></script>
    <script src="../vendor/animsition/animsition.min.js"></script>
    <script src="../vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="../vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="../vendor/circle-progress/circle-progress.min.js"></script>
    <script src="../vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="../vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="../vendor/select2/select2.min.js">
    </script>
    <script src="../js/main.js"></script>

</body>
<script>
    function dieuHuong(x){
        if(x==1) var url = "../";
        else if(x==2) var url = "../lam-bai";
        else if(x==3) var url = "../thong-tin-thanh-vien";
        else var url = "../dang-xuat"; 
        window.location=url;
    }
</script>
</html>
<!-- end document-->
<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('../meta.php');
    ?>

</head>
<body class="animsition">
    <div class="page-wrapper">
        <?php
            include_once('../menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card border border-secondary">
                                    <div class="card-header">
                                        <strong class="card-title">Thêm câu hỏi</strong>
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        if(!isset($_SESSION['user']) || $user!='lieutuanvu'){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Khu vực chỉ dành cho admin
        									</div>';
        									echo'
                                             <script>
                                             window.location="../dang-nhap";
                                             </script>';
                                        } else {
                                            /////Phan nay xu ly them cau hoi
                                            $cauHoi = isset($_POST['Cau']) ? $_POST['Cau']:'';
                                            $A = isset($_POST['A']) ? $_POST['A']:'';
                                            $B = isset($_POST['B']) ? $_POST['B']:'';
                                            $C = isset($_POST['C']) ? $_POST['C']:'';
                                            $D = isset($_POST['D']) ? $_POST['D']:'';
                                            $DA = isset($_POST['DA']) ? $_POST['DA']:'';
                                            if($cauHoi!='' && $A!='' && $B!='' && $C!='' && $D!='' && $DA!=''){
                                                $themCauHoi = $ketnoi->query("INSERT INTO `cau_hoi`(`cauhoi`, `a`, `b`, `c`, `d`, `da`) VALUES ('$cauHoi','$A','$B','$C','$D','$DA')");
                                                $themCauHoi;
                                                $idMax = 0;
                                                $layIdCauHoiMax = $ketnoi->query("SELECT max(idcauhoi) FROM `cau_hoi`");
                                                if($layIdCauHoiMax && $layIdCauHoiMax->num_rows>0){
                                                    while($row = $layIdCauHoiMax->fetch_assoc()){
                                                        $idMax = $row['max(idcauhoi)'];
                                                    }
                                                }
                                                $boDe = isset($_POST['bode']) ? $_POST['bode']: array();
                                                foreach($boDe as $de){
                                                    $themCauHoiVaoDe = $ketnoi->query("INSERT INTO `cauhoi_thuoc_bode`(`idbode`, `idcauhoi`) VALUES ('$de','$idMax')");
                                                    $themCauHoiVaoDe;
                                                }
                                                echo'
                                                <script>
                                                    window.location("../them-cau-hoi");
                                                </script>';
                                            }        
                                            //////Phan duoi hien thi form them cau hoi
                                            echo'
                                            <form action="" method="post" class="">
                                                <div class="form-group">
                                                    <div class="col col-md-12">
                                                        <label for="multiple-select" class=" form-control-label">Chọn bộ đề chứa câu hỏi (ctrl)</label>
                                                    </div>
                                                    <div class="col col-md-12">
                                                        <select name="bode[]" id="multiple-select" multiple="" class="form-control">';
                                                    $layCacBoDe = $ketnoi->query("SELECT * FROM `bo_de`");
                                                    if($layCacBoDe && $layCacBoDe->num_rows>0){
                                                        while($row=$layCacBoDe->fetch_assoc()){
                                                            echo'
                                                            <option value="'.$row['idbode'].'">'.$row['tenbode'].'</option>
                                                            ';
                                                        }
                                                    }
                                                echo'
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <i class="fa fa-question-circle"></i>
                                                        </div>
                                                        <input required type="text" name="Cau" placeholder="Câu hỏi" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <label class="switch switch-text switch-primary switch-pill">
                                                                <input required type="radio" name="DA" class="switch-input" value="1">
                                                                <span data-on="T" data-off="F" class="switch-label"></span>
                                                                <span class="switch-handle"></span>
                                                            </label>
                                                        </div>
                                                        <input required type="text" name="A" placeholder="Đáp án A" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <label class="switch switch-text switch-primary switch-pill">
                                                                <input required type="radio" name="DA" class="switch-input" value="2">
                                                                <span data-on="T" data-off="F" class="switch-label"></span>
                                                                <span class="switch-handle"></span>
                                                            </label>
                                                        </div>
                                                        <input required type="text" name="B" placeholder="Đáp án B" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <label class="switch switch-text switch-primary switch-pill">
                                                                <input required type="radio" name="DA" class="switch-input" value="3">
                                                                <span data-on="T" data-off="F" class="switch-label"></span>
                                                                <span class="switch-handle"></span>
                                                            </label>
                                                        </div>
                                                        <input required type="text" name="C" placeholder="Đáp án C" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group-addon">
                                                            <label class="switch switch-text switch-primary switch-pill">
                                                                <input required type="radio" name="DA" class="switch-input" value="4">
                                                                <span data-on="T" data-off="F" class="switch-label"></span>
                                                                <span class="switch-handle"></span>
                                                            </label>
                                                        </div>
                                                        <input required type="text" name="D" placeholder="Đáp án D" class="form-control">
                                                    </div>
                                                </div>
                                                
                                                <div class="card-footer">
                                                    <div class="form-actions form-group">
                                                        <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                                    </div>
                                                </div>
                                            </form>
                                            ';
                                        }
                                    ?>
                                
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                            include_once('../footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php
        include_once('../script.php')
    ?>
</body>

</html>

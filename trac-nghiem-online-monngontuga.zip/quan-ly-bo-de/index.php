<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('../meta.php');
    ?>
</head>
<body class="animsition">
    <div class="page-wrapper">
        <?php
            include_once('../menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr>
                                                <th>Bộ đề</th>
                                                <th  class="text-center">Thời gian</th>
                                                <th  class="text-center">Số câu hỏi</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        if(!isset($_SESSION['user']) || $user!='lieutuanvu'){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Khu vực chỉ dành cho admin
        									</div>';
        									echo'
                                            <script>
                                                window.location="../dang-nhap";
                                            </script>';
                                        } else{
                                                $layBoDe = $ketnoi->query("SELECT * FROM `bo_de` ORDER BY `idbode` DESC");
                                                if($layBoDe && $layBoDe->num_rows>0){
                                                    while($row = $layBoDe->fetch_assoc()){
                                                        $idBoDe = $row['idbode'];
                                                        $laySoCauHoiCuaDe = $ketnoi->query("SELECT * FROM `cauhoi_thuoc_bode` WHERE `idbode`='$idBoDe'");
                                                        $laySoCauHoiCuaDe;
                                                        echo'
                                                        <tr class="tr-shadow" id="'.$row['idbode'].'">
                                                            <td>'.$row['tenbode'].'</td>
                                                            <td class="text-center">'.$row['thoigian'].'</td>
                                                            <td class="text-center">'.$laySoCauHoiCuaDe->num_rows.'</td>
                                                            <td>
                                                                <div class="table-data-feature">
                                                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Sửa nội dung bộ đề" onClick="suaNoiDung('.$row['idbode'].')" data-original-title="Send">
                                                                        <i class="zmdi zmdi-mail-send"></i>
                                                                    </button>
                                                                    <button class="item" data-placement="top" data-toggle="modal" title="Sửa thông tin bộ đề" onClick="sua('.$row['idbode'].')" data-target="#suaBoDe" data-original-title="Edit">
                                                                        <i class="zmdi zmdi-edit"></i>
                                                                    </button>
                                                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Xoá bộ đề" onClick="xoaBoDe('.$row['idbode'].','."'(".$row['tenbode'].")'".')" data-original-title="Delete">
                                                                        <i class="zmdi zmdi-delete"></i>
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr class="spacer"></tr>';
                                                    }
                                                }
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php
                            include_once('../footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal medium -->
			<div class="modal fade" id="suaBoDe" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Sửa bộ đề</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body" id="chiTietBoDe">
						</div>
					</div>
				</div>
			</div>
			<!-- end modal medium -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.0.js"></script>
    <script>
    <?php
    if($user=="lieutuanvu"){
    echo'
    function thongBaoSuaBoDeThanhCong(){
        swal({
          title: "Đã sửa bộ đề!",
          icon: "success",
          button: "Quá tuyệt!",
        });
    }
    function thongBaoXoaBoDeThanhCong(){
        swal({
          title: "Đã xoá bộ đề đó!",
          icon: "success",
          button: "Quá tuyệt!",
        });
    }
    ';
    }
    ?>
    <?php
        $thongBao = isset($_GET['tb'])?$_GET['tb']:'';
        if($user=='lieutuanvu' && $thongBao=='S'){
            echo 'thongBaoSuaBoDeThanhCong();';
        }
        if($user=='lieutuanvu' && $thongBao=='X'){
            echo 'thongBaoXoaBoDeThanhCong();';
        }
    ?>
    <?php
    if($user=="lieutuanvu"){
    echo'
    function sua(idBoDe){
        document.getElementById("chiTietBoDe").innerHTML="Chờ tí...";
        $("#chiTietBoDe").load("suaBoDe.php?idbode="+idBoDe);
    }
    function suaNoiDung(idBoDe){
        window.location = "suaNoiDungBoDe.php?idbode="+idBoDe;
    }
    function xoa(idBoDe){
        window.location = "xoaBoDe.php?idbode="+idBoDe;
    }
    function xoaBoDe(idBoDe,tenBoDe){
        swal("Thiệt sự muốn bộ đề "+tenBoDe+" sao??", {
            icon: "warning",
            buttons: {
                  delete : "Xoá đi!!!",
                  cancle:"Hông xoá nữa!"
              },
        })
        .then((value)=>{
            switch (value) {
 
                case "delete":
                  xoa(idBoDe);
                  break;
             
                default:
                    swal("Okk hông xoá!");
            }
        });
    }';
    }
    ?>
    </script>

    <?php
        include_once('../script.php')
    ?>
</body>

</html>

<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
                                    <?php
                                        if(!isset($_GET['idbode']) || !isset($_SESSION['user']) || $user!='lieutuanvu'){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Khu vực chỉ dành cho admin
        									</div>';
                                            header('Location: ../quan-ly-cau-hoi');
                                        } else {
                                            /////Phan nay xu ly xoa cau hoi
                                            $idBoDe = isset($_GET['idbode']) ? $_GET['idbode'] :'';
                                            if($idBoDe!=''){
                                                $xoaCacKetQuaCuaBoDe = $ketnoi->query("DELETE FROM `diem_so` WHERE `idbode`='$idBoDe'");
                                                $xoaCacKetQuaCuaBoDe;
                                                $xoaBoDecoCauHoi = $ketnoi->query("DELETE FROM `cauhoi_thuoc_bode` WHERE `idbode`='$idBoDe'");
                                                $xoaBoDecoCauHoi;
                                                $xoaBoDe = $ketnoi->query("DELETE FROM `bo_de` WHERE `idbode`='$idBoDe'");
                                                $xoaBoDe;
                                                header('Location: ../quan-ly-bo-de?tb=X#'.($idBoDe+1));
                                            }
                                        }
                                    ?>
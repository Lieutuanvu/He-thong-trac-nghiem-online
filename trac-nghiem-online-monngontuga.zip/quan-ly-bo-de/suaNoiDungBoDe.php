<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('../meta.php');
    ?>
</head>
<body class="animsition">
    <div class="page-wrapper">
        <?php
            include_once('../menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                <?php
                                if(!isset($_SESSION['user']) || $user!='lieutuanvu' || !isset($_GET['idbode'])){
                                    header('Location: ../quan-ly-bo-de');
                                } else{
                                    $idBoDe = isset($_GET['idbode']) ? $_GET['idbode']:'';
                                    $tenBoDe = '';
                                    $layTenBoDe = $ketnoi->query("SELECT `tenbode` FROM `bo_de` WHERE `idbode`='$idBoDe'");
                                    if($layTenBoDe && $layTenBoDe->num_rows>0){
                                        while($row = $layTenBoDe->fetch_assoc()){
                                            $tenBoDe = $row['tenbode'];
                                        }
                                    } else {
                                        header('Location: ../quan-ly-bo-de');
                                    }
                                ?>
                                    <h2 class="title-1"><?php echo $tenBoDe;?></h2>
                                    <button class="au-btn au-btn-icon au-btn--blue" onClick="themCauHoiVaoBoDe(<?php echo $idBoDe;?>)" data-target="#themCauHoiVaoBoDe" data-toggle="modal">
                                        <i class="zmdi zmdi-plus"></i>Thêm câu hỏi vào bộ đề
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr class="text-center">
                                                <th>Câu hỏi</th>
                                                <th>A</th>
                                                <th>B</th>
                                                <th>C</th>
                                                <th>D</th>
                                                <th>ĐA</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                                $hDong = isset($_GET['hd']) ? $_GET['hd'] : '';
                                                $idCauHoiCanXoa = isset($_GET['idCauHoiCanXoa']) ? $_GET['idCauHoiCanXoa'] : '';
                                                if($hDong=='XKB' && $idCauHoiCanXoa!=''){
                                                    $xoaCHKhoiBD = $ketnoi->query("DELETE FROM `cauhoi_thuoc_bode` WHERE `idcauhoi`='$idCauHoiCanXoa' AND `idbode`='$idBoDe'");
                                                    if ($xoaCHKhoiBD){
                                                        echo '
                                                        <script>
                                                            window.location ="../quan-ly-bo-de/suaNoiDungBoDe.php?tb=XKB&idbode='.$idBoDe.'"
                                                        </script>';
                                                    } else {
                                                        echo '
                                                        <script>
                                                            window.location ="../quan-ly-bo-de/suaNoiDungBoDe.php?idbode='.$idBoDe.'"
                                                        </script>';
                                                    }
                                                } else if($hDong=='tch' && isset($_POST['cauHoi'])){
                                                    $cauHoi = isset($_POST['cauHoi']) ? $_POST['cauHoi']:array();
                                                    $daThem = false;
                                                    foreach($cauHoi as $idCauHoi){
                                                        $themCauHoiVaoDe = $ketnoi->query("INSERT INTO `cauhoi_thuoc_bode`(`idbode`, `idcauhoi`) VALUES ('$idBoDe','$idCauHoi')");
                                                        $themCauHoiVaoDe;
                                                        $daThem = true;
                                                    }
                                                    if($daThem){
                                                        echo '
                                                        <script>
                                                            window.location ="../quan-ly-bo-de/suaNoiDungBoDe.php?tb=tvb&idbode='.$idBoDe.'"
                                                        </script>';
                                                    } else {
                                                        echo '
                                                        <script>
                                                            window.location ="../quan-ly-bo-de/suaNoiDungBoDe.php?idbode='.$idBoDe.'"
                                                        </script>';
                                                    }
                                                    
                                                } else {
                                                    $layCauHoi = $ketnoi->query("SELECT * FROM `cau_hoi` `ch`, `cauhoi_thuoc_bode` `ctb` WHERE `ch`.idcauhoi = `ctb`.idcauhoi AND `ctb`.idbode ='$idBoDe' ORDER BY `ch`.idcauhoi DESC");
                                                    if($layCauHoi && $layCauHoi->num_rows>0){
                                                        while($row = $layCauHoi->fetch_assoc()){
                                                            $dA= '';
                                                            if($row['da']==1) $dA= 'A';
                                                            else if($row['da']==2) $dA= 'B';
                                                            else if($row['da']==3) $dA= 'C';
                                                            else $dA= 'D';
                                                            echo'
                                                            <tr class="tr-shadow" id="'.$row['idcauhoi'].'">
                                                                <td>'.$row['cauhoi'].'</td>
                                                                <td>'.$row['a'].'</td>
                                                                <td>'.$row['b'].'</td>
                                                                <td>'.$row['c'].'</td>
                                                                <td>'.$row['d'].'</td>
                                                                <td>'.$dA.'</td>
                                                                <td>
                                                                    <div class="table-data-feature">
                                                                        <button class="item" data-placement="top" data-toggle="modal" title="Sửa câu hỏi này" onClick="sua('.$row['idcauhoi'].')" data-original-title="Edit">
                                                                            <i class="zmdi zmdi-edit"></i>
                                                                        </button>
                                                                        <button class="item" data-toggle="tooltip" data-placement="top" title="Xoá câu hỏi này khỏi bộ đề" onClick="xoaCauHoiKhoiBoDe('.$row['idcauhoi'].','."'(".$row['cauhoi'].")'".','.$idBoDe.')" data-original-title="Delete">
                                                                            <i class="zmdi zmdi-delete"></i>
                                                                        </button>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr class="spacer"></tr>';
                                                        }
                                                    } else {
                                                        echo "Bộ đề này chưa có câu hỏi nào!!!";
                                                    }
                                                }
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php
                            include_once('../footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    		<div class="modal fade" id="themCauHoiVaoBoDe" tabindex="-1" role="dialog" aria-labelledby="largeModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="largeModalLabel">Thêm câu hỏi vào bộ đề</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body" id="listCauHoi">
						</div>
					</div>
				</div>
			</div>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.0.js"></script>
    <script>
    function thongBaoSuaThemCauHoiVaoDe(){
        swal({
          title: "Đã thêm (các) câu hỏi vào bộ đề này!!!",
          icon: "success",
          button: "Quá tuyệt!",
        });
    }
    function thongBaoSuaCauHoiThanhCong(){
        swal({
          title: "Đã sửa câu hỏi!",
          icon: "success",
          button: "Quá tuyệt!",
        });
    }
    function thongBaoXoaCauHoiKhoiBoDeThanhCong(){
        swal({
          title: "Đã xoá câu hỏi khỏi bộ đề!",
          icon: "success",
          button: "Quá tuyệt!",
        });
    }
    <?php
        $thongBao = isset($_GET['tb'])?$_GET['tb']:'';
        if($user=='lieutuanvu' && $thongBao=='S'){
            echo 'thongBaoSuaCauHoiThanhCong();';
        }
        if($user=='lieutuanvu' && $thongBao=='XKB'){
            echo 'thongBaoXoaCauHoiKhoiBoDeThanhCong();';
        }
        if($user=='lieutuanvu' && $thongBao=='tvb'){
            echo 'thongBaoSuaThemCauHoiVaoDe();';
        }
    ?>
    function sua(idCauHoi){
        window.open('../quan-ly-cau-hoi/#'+idCauHoi, '_blank');
    }
    function xoa(idCauHoi,idBoDe){
        window.location = "suaNoiDungBoDe.php?hd=XKB&idCauHoiCanXoa="+idCauHoi+"&idbode="+idBoDe;
    }
    function themCauHoiVaoBoDe(idBoDe){
        document.getElementById("listCauHoi").innerHTML="Chờ tí...";
        $("#listCauHoi").load("layCauHoiKhongCoTrongBoDe.php?idbode="+idBoDe);
    }
    function xoaCauHoiKhoiBoDe(idCauHoi,cauHoi,idBoDe){
        swal("Thiệt sự muốn xoá câu hỏi "+cauHoi+" khỏi bộ đề này sao??", {
            icon: "warning",
            buttons: {
                  delete : "Xoá đi!!!",
                  cancle:"Hông xoá nữa!"
              },
        })
        .then((value)=>{
            switch (value) {
 
                case "delete":
                  xoa(idCauHoi,idBoDe);
                  break;
             
                default:
                    swal("Okk hông xoá!");
            }
        });
    }
    </script>
    <?php
        include_once('../script.php')
    ?>
</body>

</html>
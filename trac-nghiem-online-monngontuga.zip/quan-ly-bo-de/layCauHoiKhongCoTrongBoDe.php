<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
    $idBoDe = isset($_GET['idbode']) ? $_GET['idbode']:'';
?>
                                    <form method="post" action="../quan-ly-bo-de/suaNoiDungBoDe.php?hd=tch&idbode=<?php echo $idBoDe;?>">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr class="text-center">
                                                <th>Câu hỏi</th>
                                                <th>A</th>
                                                <th>B</th>
                                                <th>C</th>
                                                <th>D</th>
                                                <th>ĐA</th>
                                                <th>Thêm?</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        if(!isset($_SESSION['user']) || $user!='lieutuanvu'){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Khu vực chỉ dành cho admin
        									</div>';
                                        } else if($idBoDe==''){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Lỗi ùi!!
        									</div>';
                                        } else {
                                                $layCauHoiChuaCo = $ketnoi->query("SELECT * FROM `cau_hoi` `ch`,(SELECT `idcauhoi` FROM `cau_hoi` WHERE `idcauhoi` NOT IN (SELECT `idcauhoi` FROM `cauhoi_thuoc_bode` WHERE `idbode`='$idBoDe')) `tam` WHERE `tam`.idcauhoi = `ch`.idcauhoi ORDER BY `ch`.idcauhoi DESC");
                                                if($layCauHoiChuaCo && $layCauHoiChuaCo->num_rows>0){
                                                    while($row = $layCauHoiChuaCo->fetch_assoc()){
                                                        $dA= '';
                                                        if($row['da']==1) $dA= 'A';
                                                        else if($row['da']==2) $dA= 'B';
                                                        else if($row['da']==3) $dA= 'C';
                                                        else $dA= 'D';
                                                        echo'
                                                        <tr class="tr-shadow" id="'.$row['idcauhoi'].'">
                                                            <td>'.$row['cauhoi'].'</td>
                                                            <td>'.$row['a'].'</td>
                                                            <td>'.$row['b'].'</td>
                                                            <td>'.$row['c'].'</td>
                                                            <td>'.$row['d'].'</td>
                                                            <td>'.$dA.'</td>
                                                            <td>
                                                                <label class="switch switch-text switch-primary">
                                                                  <input type="checkbox" name="cauHoi[]" value="'.$row['idcauhoi'].'" class="switch-input">
                                                                  <span data-on="+" data-off="-" class="switch-label"></span>
                                                                  <span class="switch-handle"></span>
                                                                </label>
                                                            </td>
                                                        </tr>
                                                        <tr class="spacer"></tr>';
                                                    }
                                                } else{
                                                    echo'
                                                    <div class="alert alert-danger" role="alert" style="text-align:center">
                										Bộ đề này chứa toàn bộ câu hỏi của ngân hàng ùi!!!
                									</div>';
                                                }
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                    <hr>
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </form>
<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
?>
                                    <?php
                                        if(!isset($_GET['idbode']) || !isset($_SESSION['user']) || $user!='lieutuanvu'){
                                            echo'
                                            <div class="alert alert-danger" role="alert" style="text-align:center">
        											Khu vực chỉ dành cho admin
        									</div>';
        									header('Location: ../quan-ly-bo-de');
                                        } else if(isset($_SESSION['user']) && $user=='lieutuanvu'){
                                            /////Phan nay xu ly sua cau hoi
                                            $idBoDe = isset($_GET['idbode']) ? $_GET['idbode'] :'';
                                            $thoiGian = isset($_POST['thoiGian']) ? $_POST['thoiGian']:'';
                                            $tenBoDe = isset($_POST['tenBoDe']) ? $_POST['tenBoDe']:'';
                                            $soLan = isset($_POST['solan']) ? $_POST['solan']:'';
                                            if($tenBoDe!='' && $thoiGian!='' && $idBoDe!='' && $soLan!=''){
                                                $suaBoDe = $ketnoi->query("UPDATE `bo_de` SET `tenbode`='$tenBoDe',`thoigian`='$thoiGian', `solanduocthuchien`='$soLan' WHERE `idbode`='$idBoDe'");
                                                $suaBoDe;
                                                header('Location: ../quan-ly-bo-de?tb=S#'.$idBoDe);
                                            } else if($idBoDe!=''){
                                                $layChiTietBoDe = $ketnoi->query("SELECT * FROM `bo_de` WHERE `idbode`='$idBoDe'");
                                                if($layChiTietBoDe && $layChiTietBoDe->num_rows>0){
                                                    while($in = $layChiTietBoDe->fetch_assoc()){
                                                        $Motlan = '';$Nhieulan = '';
                                                        if($in['solanduocthuchien']==1) $Motlan = 'checked';
                                                        else $Nhieulan = 'checked';
                                                        echo'
                                                        <form action="suaBoDe.php?idbode='.$idBoDe.'" method="post" class="">
                                                            <div class="form-group">
                                                                <div class="input-group">
                                                                    <div class="input-group-addon">
                                                                        <i class="fa fa-question-circle"></i>
                                                                    </div>
                                                                    <input required type="text" name="tenBoDe" value="'.$in['tenbode'].'" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-group">
                                                                    <div class="input-group-addon">
                                                                        <i class="fa fa-clock"></i>
                                                                    </div>
                                                                    <input required type="text" name="thoiGian" value="'.$in['thoigian'].'" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="row form-group">
                                                                <div class="col col-md-2">
                                                                    <label class=" form-control-label">Số lần được thực hiện:</label>
                                                                </div>
                                                                <div class="col col-md-9">
                                                                    <div class="form-check">
                                                                        <div class="radio">
                                                                            <label for="1lan" class="form-check-label ">
                                                                                <input required '.$Motlan.' type="radio" id="1lan" name="solan" value="1" class="form-check-input">Chỉ 1 lần
                                                                            </label>
                                                                        </div>
                                                                        <div class="radio">
                                                                            <label for="0lan" class="form-check-label ">
                                                                                <input required '.$Nhieulan.' type="radio" id="0lan" name="solan" value="0" class="form-check-input">Không giới hạn
                                                                            </label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="card-footer">
                                                                <div class="form-actions form-group">
                                                                    <button type="submit" class="btn btn-success btn-sm">Sửa</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                        ';
                                                    }
                                                } else {
                                                    echo "Không tìm thấy bộ đề!!";
                                                }
                                            } else{
                                                header('Location: ../quan-ly-bo-de');
                                            }
                                        }
                                    ?>

<!DOCTYPE html>
<html lang="vi">
<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('../meta.php');
    ?>
</head>
<body class="animsition">
    <div class="page-wrapper">
        <?php
            include_once('../menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card border border-secondary">
                                    <div class="card-header">
                                        <strong class="card-title">Bảng xếp hạng top 10</strong>
                                    </div>
                                    <div class="card-body">
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="xemBoDe" class=" form-control-label">Chọn bộ đề:</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="xemBoDe" id="xemBoDe" class="form-control">
                                                        <option value="0">Toàn bộ</option>
                                                        <?php
                                                        $layCacBoDe = $ketnoi->query("SELECT * FROM `bo_de`");
                                                        if($layCacBoDe && $layCacBoDe->num_rows>0)
                                                            while($row = $layCacBoDe->fetch_assoc())
                                                            
                                                                echo'<option value="'.$row['idbode'].'">'.$row['tenbode'].'</option>';
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                        <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                    
                                            <tr>
                                                <th class="text-center">TOP</th>
                                                <th class="text-center">Tài khoản</th>
                                                <th class="text-center">Tổng điểm</th>
                                                <th class="text-center">Tổng thời gian</th>
                                            </tr>
                                        </thead>
                                        <tbody id="xemTop10">
                                    <?php
                                        $top10 = $ketnoi->query("SELECT `hoten`,`avt`,`tk`.`taikhoan`,`TONGSODIEM`,`TONGTHOIGIAN` FROM `tai_khoan` `tk`, (SELECT `taikhoan`,SUM(`tongdiem`/`socau`)*100 `TONGSODIEM`,SEC_TO_TIME(SUM(TIME_TO_SEC(`thoigian`))) `TONGTHOIGIAN` FROM `diem_so` GROUP BY `taikhoan` having `tongsodiem`>0 ) `diemso` WHERE `tk`.`taikhoan`=`diemso`.`taikhoan` and `tongsodiem` is not null ORDER BY `TONGSODIEM` DESc, `TONGTHOIGIAN`");
                                        if($top10 && $top10->num_rows>0){
                                            $top = 0;
                                            while($row = $top10->fetch_assoc()){
                                                echo'
                                                <tr>
                                                    <td class="text-center">'.++$top.'</td>
                                                    <td>
                                                        <div class="col-7">
                                                            <img width="35px" height="35px" class="img rounded" src="../images/avt/'.$row['avt'].'" alt="'.$row['hoten'].'"> '.$row['taikhoan'].'
                                                        </div>
                                                    </td>
                                                    <td class="text-center">'.round($row['TONGSODIEM'],2).'</td>
                                                    <td class="text-center">'.$row['TONGTHOIGIAN'].'</td>
                                                </tr>';
                                            }
                                        }
                                    ?>
                                        </tbody>
                                    </table>
                                </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                            include_once('../footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
        include_once('../script.php')
    ?>
</body>
<script>
    $('#xemBoDe').on('change', function() {
        var idBoDe = this.value;
        document.getElementById("xemTop10").innerHTML='Xin chờ...';
        $("#xemTop10").load("getTop10.php?idbode="+idBoDe);
    });
</script>
</html>

<?php
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $idbode = isset($_GET['idbode'])?$_GET['idbode']:'';
    if($idbode!=''){
        if($idbode==0) $layTop10 = $ketnoi->query("SELECT `hoten`,`avt`,`tk`.`taikhoan`,`TONGSODIEM`,`TONGTHOIGIAN` FROM `tai_khoan` `tk`, (SELECT `taikhoan`,SUM(`tongdiem`/`socau`)*100 `TONGSODIEM`,SEC_TO_TIME(SUM(TIME_TO_SEC(`thoigian`))) `TONGTHOIGIAN` FROM `diem_so` GROUP BY `taikhoan` having `tongsodiem`>0 ) `diemso` WHERE `tk`.`taikhoan`=`diemso`.`taikhoan` and `tongsodiem` is not null ORDER BY `TONGSODIEM` DESc, `TONGTHOIGIAN`");
        else $layTop10 = $ketnoi->query("SELECT `hoten`,`avt`,`tk`.`taikhoan`,`TONGSODIEM`,`TONGTHOIGIAN` FROM `tai_khoan` `tk`,(SELECT `taikhoan`,SUM(`tongdiem`/`socau`)*100 `TONGSODIEM`, time(`thoigian`) `TONGTHOIGIAN` FROM `diem_so` WHERE `idbode`='$idbode'  GROUP BY `taikhoan` HAVING `TONGSODIEM`>0 ORDER BY `TONGSODIEM` DESC, `TONGTHOIGIAN` ASC LIMIT 10) `diemso`
WHERE `tk`.`taikhoan`=`diemso`.`taikhoan`");
        if($layTop10 && $layTop10->num_rows>0){
            $top=0;
            while($row = $layTop10->fetch_assoc()){
                echo'
                    <tr>
                        <td class="text-center">'.++$top.'</td>
                        <td>
                            <div class="col-7">
                                <img width="35px" height="35px" class="img rounded" src="../images/avt/'.$row['avt'].'" alt="'.$row['hoten'].'"> '.$row['taikhoan'].'
                            </div>
                        </td>
                        <td class="text-center">'.round($row['TONGSODIEM'],2).'</td>
                        <td class="text-center">'.$row['TONGTHOIGIAN'].'</td>
                    </tr>';
            }
        } else {
            echo'Bộ đề này chưa có ai làm cả!!';
        }
    }
?>
<!DOCTYPE html>
<html lang="vi">
<?php
    $executionStartTime = microtime(true);
    $thoiGianKT = '';
    $coLamBai = 0;
    $boDeDangLam = '';
    include_once('../csdl.php');
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $user = isset($_SESSION['user']) ? $_SESSION['user']:'';
    $tenBoDe='';
    $thoiGian=0;
    $soLan=0;
?>
<head>
    <title>Hệ thống làm bài trăc nghiệm</title>
    <?php
        include_once('../meta.php');
    ?>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <?php
            include_once('../menu.php');
        ?>
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p15">
                    <div class="container-fluid">
                        <div class="row" id="baiLam">
                            <div class="col-md-12">
                                <div class="card border border-secondary">
                                    <div class="card-header">
                                        <strong class="card-title" id="tenBoDe">Xem bộ đề</strong>
                                    </div>
                                    <div class="card-body">
                                    <?php
                                        if(!isset($_SESSION['user'])){
                                            echo'
                                            <script>
                                                window.location="../dang-nhap";
                                            </script>
                                            ';
                                        } else if(!isset($_GET['idbode'])){
                                            echo'
                                            <script>
                                                window.location="../";
                                            </script>
                                            ';
                                        } else if(isset($_GET['idbode'])){
                                            $idDe = $_GET['idbode'];
                                            $layThongTin=$ketnoi->query("SELECT * FROM `bo_de` WHERE `idbode`='$idDe'");
                                            $layThongTinSoCH=$ketnoi->query("SELECT * FROM `cauhoi_thuoc_bode` WHERE `idbode`='$idDe'");
                                            $layThongTinSoCH;
                                            $layThongTinKQ=$ketnoi->query("SELECT * FROM `diem_so` WHERE `idbode`='$idDe' AND `taikhoan`='$user'");
                                            $layThongTinDangLam=$ketnoi->query("SELECT * FROM `dang_lam_bo_de` WHERE `idbode`='$idDe' AND `taikhoan`='$user'");
                                            if($layThongTin && $layThongTin->num_rows>0){
                                                while($row = $layThongTin->fetch_assoc()){
                                                    $tenBoDe=$row['tenbode'];
                                                    $thoiGian=$row['thoigian'];
                                                    $soLan=$row['solanduocthuchien'];
                                                }
                                                if($soLan==0) $soLan="Không giới hạn";
                                                $soCauHoi = $layThongTinSoCH->num_rows;
                                                echo'
                                                    <div class="col-md-12 text-center">
                                                        Số câu hỏi: '.$soCauHoi.' câu<br>
                                                        Thời gian: '.$thoiGian.' phút<br>
                                                        Số lần được thực hiện: '.$soLan.' lần<br>
                                                        Cách lấy điểm: Lần gần nhất
                                                    </div>
                                                    <script>
                                                        document.getElementById("tenBoDe").innerHTML="Tên bộ đề: "+"'.$tenBoDe.'";
                                                    </script>';
                                                if($layThongTinKQ && $layThongTinKQ->num_rows>0){
                                                    echo'
                                                    <div class="table-responsive m-b-40">
                                                        <table class="table table-borderless table-data3">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">Điểm</th>
                                                                    <th class="text-center">Thời gian</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody id="KqCu">';
                                                    while($in = $layThongTinKQ->fetch_assoc()){
                                                        echo'
                                                                <tr>
                                                                    <td class="text-center">'.$in['tongdiem'].'/'.$in['socau'].'</td>
                                                                    <td class="text-center">'.$in['thoigian'].'</td>
                                                                </tr>';
                                                    }
                                                    echo'
                                                            </tbody>
                                                
                                                        </table>
                                                    </div>';
                                                    if($layThongTinDangLam && $layThongTinDangLam->num_rows>0){
                                                        echo'<button type="button" onClick="lam('.$idDe.')" class="btn btn-outline-warning btn-lg btn-block">Làm tiếp đang dở dang</button>';
                                                        echo'
                                                               
                                                        <script>
                                                            var para = document.createElement("KqCu");
                                                            var t = document.createTextNode("<tr>Đang làm dở</tr>");
                                                            para.appendChild(t);  
                                                            $("#KqCu").append("<tr>Đang làm dở</tr>");
                                                        </script>';                                                        
                                                    }
                                                    else if($soLan=="Không giới hạn")
                                                        echo'<button type="button" onClick="lam('.$idDe.')" class="btn btn-outline-secondary btn-lg btn-block">Làm lại</button>';
                                                } else
                                                        echo'<button type="button" onClick="lam('.$idDe.')" class="btn btn-outline-secondary btn-lg btn-block">Bắt đầu</button>';
                                                    
                                            } 
                                            else if($layThongTin && $layThongTin->num_rows<=0)
                                                echo'
                                                    <script>
                                                        window.location="../";
                                                    </script>
                                                    ';
                                        }
                                        
                                    ?>
                                
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                            include_once('../footer.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php
        include_once('../script.php')
    ?>
    <script>
</script>
</body>
<script>
    function lam(idbode){window.location="../lam-bai/?idbode="+idbode;}
</script>
</html>
